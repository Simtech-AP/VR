/*
 * battery.h
 *
 *  Created on: 05.05.2020
 */

#ifndef BATTERY_H_
#define BATTERY_H_


#define BATTERY_SAMPLES_IN_AVG					25			// ilosc probek potrzebnych do policzenia jednej sredniej
#define BATTERY_AVERAGES_LEN					10			// ilosc przechowywanych srednich pomiaru napiecia na akumulatorach
#define BATTERY_OFF_ADC_LEVEL					2974		// wartosc ADC akumulatora, dla krtorej powinien sie wylaczyc
#define BATTERY_COUNT_PERIOD					5000		// okres aktualizacji wartosci napiecia na akumulatorach

// zrodla callbacka liczacego stan naladowania akumulatorow
#define BATTERY_ADC_CALLBACK_SOURCE_DMA			1
#define BATTERY_ADC_CALLBACK_SOURCE_TIM			2


typedef enum
{
	init = 0,
	pendant_on = 1,
	battery_charging = 2,
	battery_charged = 3,
	low_battery = 4,
	pendant_off = 5
}chrg_led_state_type;


uint16_t BATTERY_get_voltage();												// pobranie wartosci napiecia na akumulatorach
uint16_t BATTERY_get_percentage();											// pobranie procentu naladowania akumulatorow
void BATTERY_check_battery_level();											// aktualizacja wartosci napiecia na akumulatorach
void BATTERY_turn_off();													// wylaczenie pendanta na przycisku
void TRACKER_chrg_on();														// wlaczenie ladowania trackera
void TRACKER_chrg_off();													// wylaczenie ladowania trackera
void TRACKER_check_timeout();												// sprawdzenie timeoutu ladowania trackera
void CHRG_LED_check(uint8_t on);											// sprawdzenie stanu akumulatora i aktualizacja stanu led
void CHRG_LED_change(chrg_led_state_type state);							// aktualizacja stanu led
void ADC_init(ADC_HandleTypeDef *hadc, DMA_HandleTypeDef *hdma_adc);		// inicjalizacja ADC
void ADC_BatteryCallback(uint8_t source);									// przetwarzanie wartosci z ADC, wywolywane w przerwaniu z DMA


#endif /* BATTERY_H_ */
