/*
 * uart_touchpad.h
 *
 *  Created on: 09.05.2020
 */

#ifndef UART_TOUCHPAD_H_
#define UART_TOUCHPAD_H_


#define TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE		100						// rozmiar bufora na ramkie ze stanem przyciskow
#define TOUCHPAD_RX_BUFFER_SIZE					18						// rozmiar ramki przychodzacej

void TOUCHPAD_init(UART_HandleTypeDef *huart, TIM_HandleTypeDef *htim);	// inicjalizacja UARTa
void TOUCHPAD_UART_RxCallback(UART_HandleTypeDef *huart);				// callback od odebioru danych
uint16_t TOUCHPAD_waitingSwitchFrames(uint8_t *data);					// pobranie ramek ze stanem przycisk�w z bufora
uint16_t TOUCHPAD_waitingTouchFrame(uint8_t *data);						// pobranie ramki ze stanem touchpada z bufora
uint8_t TOUCHPAD_turnOn(UART_HandleTypeDef *huart);						// wyslanie komendy "start" do touchpada
uint8_t TOUCHPAD_turnOff(UART_HandleTypeDef *huart);					// wyslanie komendy "stop" do touchpada
void TOUCHPAD_watchdog(UART_HandleTypeDef *huart);						// wyslanie ramki resetujacej watchdoga touchpada

#endif /* UART_TOUCHPAD_H_ */
