/*
 * esp_cycl_buf.h
 *
 *  Created on: 11.10.2019
 */

#ifndef ESP_CYCL_BUF_H_
#define ESP_CYCL_BUF_H_


#define CYCLICAL_BUFFER_SIZE			200			// rozmiar bufora cyklicznego dla modulu WiFi
#define CYCLICAL_BUFFER_MAX_MSG_COUNT	100			// maksymalna ilosc wiadomosci w buforze

uint8_t CYCL_BUF_get_data();						// pobranie znaku z bufora cyklicznego
void CYCL_BUF_set_data(uint8_t data);				// dodanie znaku do bufora cyklicznego
uint8_t CYCL_BUF_check_new_frame_flag();			// sprawdzenie flagi odebrania nowej wiadomosci
uint8_t CYCL_BUF_check_frame_length();				// pobranie dlugosci nowej wiadomosci
void CYCL_BUF_clear();								// wyczyszczzenie bufora cyklicznego

#endif /* ESP_CYCL_BUF_H_ */
