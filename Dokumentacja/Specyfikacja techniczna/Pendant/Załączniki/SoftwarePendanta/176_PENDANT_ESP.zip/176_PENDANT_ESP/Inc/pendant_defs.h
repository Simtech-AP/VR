/*
 * pendant_defs.h
 *
 *  Created on: 30.05.2020
 */

#ifndef PENDANT_DEFS_H_
#define PENDANT_DEFS_H_

// id ramek z aktualnym stanem pendanta
#define FRAME_TYPE_BUTTON_DOWN		1
#define FRAME_TYPE_BUTTON_UP		2
#define FRAME_TYPE_BROADCAST		8
#define FRAME_TYPE_BATTERY			9
#define FRAME_TYPE_TOUCH_STATE		10

// id ramek z poleceniami
#define PENDANT_DBG_ID_NONE			0
#define PENDANT_DBG_ID_SSID			20
#define PENDANT_DBG_ID_RSSI			21
#define PENDANT_DBG_ID_FRM_CNT		22
#define PENDANT_DBG_ID_BAT_V		23
#define PENDANT_DBG_ID_MAC			24
#define PENDANT_TRACKER_CHRG_ID		30
#define PENDANT_TRACKER_NCHRG_ID	31
#define PENDANT_DBG_ID_FIRST		20
#define PENDANT_DBG_ID_LAST			24

// tryby pracy pendanta
#define PENDANT_MODE_WIFI			0
#define PENDANT_MODE_CFG			1
#define PENDANT_MODE_USB			2
#define PENDANT_MODE_WIFIUSB		3

// stan trybu dbg (WiFi + USB)
#define PENDANT_MODE_WIFIUSB_OFF	0
#define PENDANT_MODE_WIFIUSB_ENTER	1
#define PENDANT_MODE_WIFIUSB_ON		2

#endif /* PENDANT_DEFS_H_ */
