/*
 * uart_cfg_mode.h
 *
 *  Created on: 25.06.2019
 */

#ifndef UART_CFG_MODE_H_
#define UART_CFG_MODE_H_

// flagi zmiany parametrow w trakcie aktualnego trybu konfiguracji
#define STATUS_CHANGE_IP					0x01
#define STATUS_CHANGE_SSID					0x02
#define STATUS_CHANGE_KEY					0x04
#define STATUS_CHANGE_TCP_PORT				0x08
#define STATUS_CHANGE_UDP_PORT				0x10
#define STATUS_CHANGE_TIME					0x20

#define CFG_MODE_MAX_RX_MSG_SIZE			15			// maksymalna dlugosc wiadomosci
#define CFG_MODE_RX_BUFFER_SIZE				50			// rozmiar bufora cyklicznego odbiorczego

typedef enum											// statusy odebrania wiadomosci
{
	none = 0,
	get_ssid = 1,
	get_key = 2,
	get_ip = 3,
	get_tcp_port = 4,
	get_udp_port = 5,
	set_ssid = 6,
	set_key = 7,
	set_ip = 8,
	set_tcp_port = 9,
	set_udp_port = 10,
	data_ssid = 11,
	data_key = 12,
	data_ip = 13,
	data_tcp_port = 14,
	data_udp_port = 15,
	get_time = 16,
	set_time = 17,
	data_time = 18
}cfg_mode_parameter_enum;

void UART_cfg_mode_receive(uint8_t cfg_mode_rx);		// dopisanie odebranego z USB znaku do bufora
void UART_cfg_mode(UART_HandleTypeDef *huart_esp);		// funkcja glowna trybu konfiguracji
uint8_t UART_check_binaryRx_frame();					// sprawdzenie odebrania z USB ramki z poleceniem

#endif /* UART_CFG_MODE_H_ */
