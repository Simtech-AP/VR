/*
 * esp_comm.h
 *
 *  Created on: 11.10.2019
 */

#ifndef ESP_COMM_H_
#define ESP_COMM_H_


// statusy polaczenia pendanta z siecia i aplikacja
#define ESP_CONN_STAT_WIFI_DISCONN	0x00
#define ESP_CONN_STAT_WIFI_CONN		0x01
#define ESP_CONN_STAT_WIFI_IP		0x02
#define ESP_CONN_STAT_BROAD_OPEN	0x04
#define ESP_CONN_STAT_TCP_OPEN		0x08
#define ESP_CONN_STAT_TCP_CONN		0x10
#define ESP_CONN_STAT_SIMTECH		0x20

#define SOCKET_LIST_SIZE			10													// ilosc gniazd modulu WiFi


typedef enum
{
	wifi_none = 0,
	wifi_connected = 1,
	wifi_got_ip = 2,
	wifi_disconnected = 3
}esp_wifi_status_enum;

typedef enum
{
	socket_none = 0,
	socket_connect = 1,
	socket_closed = 2,
	socket_connect_fail = 3
}esp_socket_status_enum;

typedef enum
{
	cmd_none = 0,
	cmd_ok = 1,
	cmd_error = 2
}esp_cmd_status_enum;


void ESP_UART_RxCallback(uint8_t x);													// zapisanie odebranego znaku w buforze cyklicznym
void ESP_reset(UART_HandleTypeDef *huart);												// reset modulu WiFi
void ESP_off();																			// wylaczenie modulu WiFi

uint8_t ESP_update(UART_HandleTypeDef *huart);											// sprawdzenie i odczytanie wiadomosci z bufora
uint8_t ESP_send_udp(UART_HandleTypeDef *huart, uint8_t *buf, uint8_t size);			// wyslanie broadcasta
uint8_t ESP_send_tcp(UART_HandleTypeDef *huart, uint8_t *buf, uint16_t size);			// wyslanie ramki TCP
uint32_t ESP_get_send_frames_counter();													// pobranie licznika wyslanych ramek
uint8_t ESP_check_binaryRx_frame();														// sprawdzenie odebrania polecenia

uint8_t ESP_at_cwjap_ask(UART_HandleTypeDef *huart, uint8_t *out);						// wyslanie zapytania CWJAP - pobranie informacji o sieci WiFi
uint8_t ESP_at_cipstamac_ask(UART_HandleTypeDef *huart, uint8_t *out);					// wyslanie zapytania CIPSTAMAC - pobranie adresu MAC modulu WiFi
uint8_t ESP_at_cipserver(UART_HandleTypeDef *huart, uint16_t port);						// wyslanie komendy CIPSERVER - otwarcie portu servera TCP
uint8_t ESP_at_cipsto(UART_HandleTypeDef *huart, uint16_t timeout);						// wyslanie komendy CIPSTO - ustawienie timeoutu servera TCP
uint8_t ESP_at_cipstart(UART_HandleTypeDef *huart, uint16_t port);						// wyslanie komendy CIPSTART - otwarcie portu UDP
uint8_t ESP_at_cwdhcp(UART_HandleTypeDef *huart);										// wyslanie komendy CWDHCP - wylaczenie DHCP
uint8_t ESP_at_cwmode(UART_HandleTypeDef *huart);										// wyslanie komendy CWMODE - wejscie w tryb stacji
uint8_t ESP_at_cipsta(UART_HandleTypeDef *huart, uint8_t *ip);							// wyslanie komendy CIPSTA - ustawienie statycznego adresu IP
uint8_t ESP_at_cwjap(UART_HandleTypeDef *huart, char *ssid, char *key);					// wyslanie komendy CWJAP - ustawienie nazwy i hasla sieci


#endif /* ESP_COMM_H_ */
