/*
 * modes.h
 *
 *  Created on: 05.05.2020
 */

#ifndef MODES_H_
#define MODES_H_

void PendantModes_init(uint8_t *ip);										// inicjalizacja buforow nadawczych

// funkcje wysylajace wiadomosci w sposob zalezny od trybu pendanta

uint8_t PendantSend_broadcast(uint8_t mode);								// wysylanie broadcastu

uint8_t PendantSend_button(uint8_t mode, uint8_t type, uint8_t number);		// wyslanie zmiany stanu deadmanow lub e-stopu
uint8_t PendantSend_battery(uint8_t mode, uint8_t val);						// wyslanie poziomu naladowania baterii
uint8_t PendantSend_switch(uint8_t mode, uint8_t *data, uint16_t size);		// wyslanie stanu przyciskow
uint8_t PendantSend_touch(uint8_t mode, uint8_t *data);						// wyslanie stanu touchpada

uint8_t PendantSend_dbg_ssid(uint8_t mode, uint8_t *buf, uint8_t len);		// wyslanie nazwy sieci
uint8_t PendantSend_dbg_rrsi(uint8_t mode, uint8_t *buf, uint8_t len);		// wyslanie sily sygnalu
uint8_t PendantSend_dbg_mac(uint8_t mode, uint8_t *buf, uint8_t len);		// wyslanie adresu MAC sieci
uint8_t PendantSend_dbg_bat(uint8_t mode, uint16_t bat);					// wyslanie napiecia na akumulatorach
uint8_t PendantSend_dbg_cnt(uint8_t mode, uint32_t cnt);					// wyslanie licznika wyslanych ramek

#endif
