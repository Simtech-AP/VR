/*
 * uart_cfg_mode.c
 *
 *  Created on: 25.06.2019
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stm32f1xx_hal.h"
#include "usbd_cdc_if.h"
#include "uart_cfg_mode.h"
#include "esp_comm.h"
#include "main.h"
#include "pendant_defs.h"


extern volatile uint8_t pendant_power_save_counter_s;						// licznik sekund bezczynnosci
extern volatile uint8_t pendant_power_save_counter_min;						// licznik minut bezczynnosci
extern uint8_t pendant_mode;												// tryb pendanta
extern uint8_t pendant_mode_is_wifi_usb;									// status wejscia w tryb DBG (WiFi + USB)
extern uint8_t pendant_is_on;												// flaga wlaczenia pendanta

uint8_t cfg_mode_rx_buffer[CFG_MODE_RX_BUFFER_SIZE];						// cykliczny bufor odbiorczy USB
uint8_t cfg_mode_rx_check_buffer[CFG_MODE_MAX_RX_MSG_SIZE];					// bufor do weryfikacji odebranej wiadomosci
uint8_t UART_Tx_cfg_buf[50];												// bufor nadawczy USB trybu konfiguracji
uint8_t cfg_mode_rx_buffer_index = 0;										// wskaznik do zapisu w buforze cyklicznym

uint8_t UART_dbg_frame_id = PENDANT_DBG_ID_NONE;							// status odebrania ramki z poleceniem
volatile cfg_mode_parameter_enum cfg_mode_parameter = 0;					// status odebrania komendy
volatile uint8_t cfg_wait_for_data = 0;										// status oczekiwania na dane konfiguracyjne

uint16_t cfg_tcp_port;														// zmienna na nowy numer portu TCP
uint16_t cfg_multicast_port;												// zmienna na nowy numer portu UDP
uint16_t cfg_time;															// zmienna na nowy czas oczekiwania na uspienie
char cfg_ssid[16];															// zmienna na nowe SSID
char cfg_key[16];															// zmienna na nowe haslo
uint8_t cfg_ip_addr[4];														// zmienna na nowy adres IP
uint8_t cfg_data[CFG_MODE_MAX_RX_MSG_SIZE];									// bufor do zapisania lancucha znakowego parametru liczbowego


uint8_t get_ip_from_string()												// sprawdzenie poprawnosci adresu IP
{
	uint8_t i;
	uint8_t offset = 0;														// poczatek aktualnej liczby w buforze globalnym
	uint8_t tmp[4] = {0, 0, 0, 0};											// bufor lokalny na bajty adresu IP
	uint8_t ind = 0;														// indeks bufora lokalnego na bajty adresu IP
	int t;

	for(i = 0; i < CFG_MODE_MAX_RX_MSG_SIZE; i++)							// sprawdzenie wszystkich znakow w buforze globalnym
	{
		if(cfg_data[i] == 0)												// koniec lancucha znakow w buforze globalnym
			break;

		if(cfg_data[i] == '.')												// koniec aktualnej liczby w buforze globalnym
		{
			if(ind == 3)													// znalezienie czwartej kropki w adresie IP - blad
				return 0;

			if(i == offset)													// brak znaku miedzy kropkami w adresie IP - blad
				return 0;

			t = atoi((const char*)(cfg_data + offset));						// konwersja aktualnej liczby adresu IP
			if((t < 0) ||(t > 0xff))										// liczba spoza zakresu 1 bajta - blad
				return 0;
			tmp[ind] = (uint8_t)t;											// zapisanie bajtu adresu IP w buforze lokalnym

			offset = i + 1;													// przesuniecie poczatku nowej liczby za kropke
			ind++;															// inkrementacja indeksu bufora lokalnego na bajty adresu IP
		}
		else
		{
			if((cfg_data[i] < '0') || (cfg_data[i] > '9'))					// w adresie IP jest inny znak niz kropka albo cyfra - blad
				return 0;
		}
	}

	if(ind != 3)															// znaleziono mniej niz trzy kropki w adresie IP - blad
		return 0;

	t = atoi((const char*)(cfg_data + offset));								// konwersja ostatniej liczby adresu IP
	if((t < 0) || (t > 0xff))												// liczba spoza zakresu 1 bajta - blad
		return 0;

	if(t == 0)																// jesli ostatnia liczba adresu IP jest rowna 0
		if(cfg_data[offset] != '0')											// nalezy sprawdzic, czy to 0 znajduje sie w buforze globalnym
			return 0;
	tmp[ind] = (uint8_t)t;													// zapisanie bajtu adresu IP w buforze lokalnym

	for(i = 0; i < 4; i++)													// przepisanie adresu IP w odpowiedniej zmiennej globalnej
		cfg_ip_addr[i] = tmp[i];

	return 1;
}


uint8_t check_message()														// sprawdzenie odebranej wiadomosci
{
	uint8_t index = cfg_mode_rx_buffer_index - 1;							// indeks znaku konca wiadomosci (0xd)
	uint8_t cfg_mode_state = pendant_mode;									// tryb pendanta
	uint8_t i, tmp;

	if(index > CFG_MODE_RX_BUFFER_SIZE)										// jesli cfg_mode_rx_buffer_index == 0 to index == 255
		index = CFG_MODE_RX_BUFFER_SIZE - 1;								// ustawienie zmiennej index na koniec bufora cyklicznego

	for(i = CFG_MODE_MAX_RX_MSG_SIZE; i > 0; i--)							// pobranie ostatnich CFG_MODE_MAX_RX_MSG_SIZE znakow z bufora cyklicznego
	{
		index--;
		if(index > CFG_MODE_RX_BUFFER_SIZE)
			index = CFG_MODE_RX_BUFFER_SIZE - 1;
		cfg_mode_rx_check_buffer[i - 1] = cfg_mode_rx_buffer[index];		// najnowsza wiadomosc w buforze do weryfikacji
		if(cfg_mode_rx_check_buffer[i - 1] == 0xd)							// poczatek poprzedniej wiadomosci
			break;
	}

	if(cfg_wait_for_data)													// oczekiwanie na wartosc parametru
	{
		tmp = i;															// indeks poczatku wiadomosci w buforze do weryfikacji
		switch(cfg_wait_for_data)
		{
		case STATUS_CHANGE_KEY:
		{
			for(i = 0; i < CFG_MODE_MAX_RX_MSG_SIZE; i++)					// zapisanie hasla w odpowiedniej zmiennej
			{
				if(i + tmp < CFG_MODE_MAX_RX_MSG_SIZE)
					cfg_key[i] = cfg_mode_rx_check_buffer[i + tmp];
				else
					cfg_key[i] = 0;
			}
			break;
		}
		case STATUS_CHANGE_SSID:
		{
			for(i = 0; i < CFG_MODE_MAX_RX_MSG_SIZE; i++)					// zapisanie SSID w odpowiedniej zmiennej
			{
				if(i + tmp < CFG_MODE_MAX_RX_MSG_SIZE)
					cfg_ssid[i] = cfg_mode_rx_check_buffer[i + tmp];
				else
					cfg_ssid[i] = 0;
			}
			break;
		}
		case STATUS_CHANGE_TCP_PORT:
		case STATUS_CHANGE_UDP_PORT:
		case STATUS_CHANGE_IP:
		case STATUS_CHANGE_TIME:
		{
			for(i = 0; i < CFG_MODE_MAX_RX_MSG_SIZE; i++)					// zapisanie parametrow liczbowych w odpowiedniej zmiennej
			{
				if(i + tmp < CFG_MODE_MAX_RX_MSG_SIZE)
					cfg_data[i] = cfg_mode_rx_check_buffer[i + tmp];
				else
					cfg_data[i] = 0;
			}
			break;
		}
		}

		switch(cfg_wait_for_data)											// ustawienie statusu odebrania parametru
		{
		case STATUS_CHANGE_IP:
		{
			cfg_mode_parameter = data_ip;
			break;
		}
		case STATUS_CHANGE_KEY:
		{
			cfg_mode_parameter = data_key;
			break;
		}
		case STATUS_CHANGE_SSID:
		{
			cfg_mode_parameter = data_ssid;
			break;
		}
		case STATUS_CHANGE_TCP_PORT:
		{
			cfg_mode_parameter = data_tcp_port;
			break;
		}
		case STATUS_CHANGE_UDP_PORT:
		{
			cfg_mode_parameter = data_udp_port;
			break;
		}
		case STATUS_CHANGE_TIME:
		{
			cfg_mode_parameter = data_time;
			break;
		}
		}
		cfg_wait_for_data = 0;
		return cfg_mode_state;												// wiadomosci sprawdzona, pendant w trybie konfiguracji
	}

	if(cfg_mode_state != PENDANT_MODE_CFG)									// poza trybem konfiguracji sprawdzane jest tylko wejscie albo wyjscie z trybu
		i = CFG_MODE_MAX_RX_MSG_SIZE - 8;

	switch(i)																// switch sprawdza wiadomosci o podanej dlugosci i dluzsze, brak break'ow nie jest bledem
	{
	case CFG_MODE_MAX_RX_MSG_SIZE - 12:										// get / set tcp / udp port
	{
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 12, "set tcp port", 12))
		{
			cfg_mode_parameter = set_tcp_port;
			return cfg_mode_state;
		}
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 12, "get tcp port", 12))
		{
			cfg_mode_parameter = get_tcp_port;
			return cfg_mode_state;
		}
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 12, "set udp port", 12))
		{
			cfg_mode_parameter = set_udp_port;
			return cfg_mode_state;
		}
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 12, "get udp port", 12))
		{
			cfg_mode_parameter = get_udp_port;
			return cfg_mode_state;
		}
	}
	case CFG_MODE_MAX_RX_MSG_SIZE - 11:
	case CFG_MODE_MAX_RX_MSG_SIZE - 10:
	case CFG_MODE_MAX_RX_MSG_SIZE - 9:
	case CFG_MODE_MAX_RX_MSG_SIZE - 8:										// cfg / usb /dbg mode, set / get ssid
	{
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "cfg mode", 8))
		{
			if(cfg_mode_state != PENDANT_MODE_USB)
				cfg_mode_state = PENDANT_MODE_CFG;
			return cfg_mode_state;
		}
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "usb mode", 8))
		{
			if(cfg_mode_state != PENDANT_MODE_CFG)
				cfg_mode_state = PENDANT_MODE_USB;
			return cfg_mode_state;
		}
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "dbg mode", 8))
		{
			if(cfg_mode_state == PENDANT_MODE_WIFI)
				cfg_mode_state = PENDANT_MODE_WIFIUSB;
			return cfg_mode_state;
		}
		if(cfg_mode_state == PENDANT_MODE_CFG)								// pomijane poza trybem konfiguracji
		{
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "set ssid", 8))
			{
				cfg_mode_parameter = set_ssid;
				return cfg_mode_state;
			}
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "get ssid", 8))
			{
				cfg_mode_parameter = get_ssid;
				return cfg_mode_state;
			}
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "set time", 8))
			{
				cfg_mode_parameter = set_time;
				return cfg_mode_state;
			}
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 8, "get time", 8))
			{
				cfg_mode_parameter = get_time;
				return cfg_mode_state;
			}
		}
	}
	case CFG_MODE_MAX_RX_MSG_SIZE - 7:										// set / get key
	{
		if(cfg_mode_state == PENDANT_MODE_CFG)								// pomijane poza trybem konfiguracji
		{
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 7, "set key", 7))
			{
				cfg_mode_parameter = set_key;
				return cfg_mode_state;
			}
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 7, "get key", 7))
			{
				cfg_mode_parameter = get_key;
				return cfg_mode_state;
			}
		}
	}
	case CFG_MODE_MAX_RX_MSG_SIZE - 6:										// set / get ip
	{
		if(cfg_mode_state == PENDANT_MODE_CFG)								// pomijane poza trybem konfiguracji
		{
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 6, "set ip", 6))
			{
				cfg_mode_parameter = set_ip;
				return cfg_mode_state;
			}
			if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 6, "get ip", 6))
			{
				cfg_mode_parameter = get_ip;
				return cfg_mode_state;
			}
		}
	}
	case CFG_MODE_MAX_RX_MSG_SIZE - 5:
	case CFG_MODE_MAX_RX_MSG_SIZE - 4:										// exit
	{
		if(!memcmp(cfg_mode_rx_check_buffer + CFG_MODE_MAX_RX_MSG_SIZE - 4, "exit", 4))
		{
			cfg_mode_state = PENDANT_MODE_WIFI;								// z kazdego trybu wychodzi sie do trybu WiFi
			cfg_mode_parameter = none;
			return cfg_mode_state;
		}
	}
	case CFG_MODE_MAX_RX_MSG_SIZE - 3:
	case CFG_MODE_MAX_RX_MSG_SIZE - 2:										// odebranie komendy wlaczenia / wylaczenia ladowania trackera (id + id + \r)
	{
		if(cfg_mode_rx_check_buffer[CFG_MODE_MAX_RX_MSG_SIZE - 2] == cfg_mode_rx_check_buffer[CFG_MODE_MAX_RX_MSG_SIZE - 1])
			if(cfg_mode_rx_check_buffer[CFG_MODE_MAX_RX_MSG_SIZE - 2] >= PENDANT_TRACKER_CHRG_ID)
				if(cfg_mode_rx_check_buffer[CFG_MODE_MAX_RX_MSG_SIZE - 2] <= PENDANT_TRACKER_NCHRG_ID)
				{
					UART_dbg_frame_id = cfg_mode_rx_check_buffer[CFG_MODE_MAX_RX_MSG_SIZE - 2];
					return cfg_mode_state;
				}
	}
	}

	return cfg_mode_state;
}


uint8_t UART_check_binaryRx_frame()											// sprawdzenie odebrania z USB ramki z poleceniem
{
	uint8_t tmp = UART_dbg_frame_id;

	UART_dbg_frame_id = PENDANT_DBG_ID_NONE;								// resetowanie odebranej wiadomosci

	return tmp;
}


void UART_cfg_mode_receive(uint8_t cfg_mode_rx)								// dopisanie odebranego z USB znaku do bufora
{
	HAL_GPIO_TogglePin(LED1);
	if(!pendant_is_on)														// ignorowanie znakow odebrancyh podczas ladowania
		return;

	cfg_mode_rx_buffer[cfg_mode_rx_buffer_index] = cfg_mode_rx;				// dodanie nowego znaku do bufora cyklicznego
	cfg_mode_rx_buffer_index++;												// inkrementacja wskaznika bufora cyklicznego
	if(cfg_mode_rx_buffer_index == CFG_MODE_RX_BUFFER_SIZE)					// przepelnienie bufora cyklicznego - zapisywanie od poczatku
		cfg_mode_rx_buffer_index = 0;
	if(cfg_mode_rx == 0xd)													// odebranie znaku konca wiadomosci
	{
		pendant_mode = check_message();										// sprawdzenie odebranej wiadomosci
		if(pendant_mode == PENDANT_MODE_WIFIUSB)
		{
			if(!pendant_mode_is_wifi_usb != PENDANT_MODE_WIFIUSB_OFF)		// wejscie w tryb DBG (WiFi + USB)W
				pendant_mode_is_wifi_usb = PENDANT_MODE_WIFIUSB_ENTER;
		}
		else																// wyjscie z trybu DBG (WiFi + USB)W
			pendant_mode_is_wifi_usb = PENDANT_MODE_WIFIUSB_OFF;
	}
}


void save_cfg_data(uint8_t status)											// zapisanie parametrow w pamieci FLASH
{
	uint16_t buffer[SIZE_BUFFER_CFG_DATA];									// bufor lokalny do zapisu
	uint8_t *ptr = (uint8_t*)buffer;										// wskaznik typu uint8_t na bufor do zapisu
	FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t PageError;
	uint32_t address = CFG_DATA_START_ADDRESS;								// adres parametrow w pamieci FLASH
	uint8_t i;
	uint16_t *ptr16 = (uint16_t*)CFG_DATA_START_ADDRESS;					// wskaznik na miejsce w pamieci FLASH

	for(i = 0; i < SIZE_BUFFER_CFG_DATA; i++)								// pobranie parametrow z pamieci FLASH do bufora lokalnego
		buffer[i] = ptr16[i];

	if(status & STATUS_CHANGE_SSID)											// zmiana SSID w buforze lokalnym
		for(i = 0; i < 16; i++)
			ptr[i] = cfg_ssid[i];
	if(status & STATUS_CHANGE_KEY)											// zmiana hasla w buforze lokalnym
		for(i = 0; i < 16; i++)
			ptr[i + 16] = cfg_key[i];
	if(status & STATUS_CHANGE_IP)											// zmiana adresu IP w buforze lokalnym
		for(i = 0; i < 4; i++)
			ptr[i + 32] = cfg_ip_addr[i];
	if(status & STATUS_CHANGE_TCP_PORT)										// zmiana numeru portu TCP w buforze lokalnym
		buffer[18] = cfg_tcp_port;
	if(status & STATUS_CHANGE_UDP_PORT)										// zmiana numeru portu UDP w buforze lokalnym
		buffer[19] = cfg_multicast_port;
	if(status & STATUS_CHANGE_TIME)											// zmiana czasu oczekiwania na uspienie w buforze lokalnym
		buffer[20] = cfg_time;

	HAL_FLASH_Unlock();														// odblokowanie pamieci FLASH

	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.NbPages = 1;
	EraseInitStruct.PageAddress = CFG_DATA_START_ADDRESS;
	HAL_FLASHEx_Erase(&EraseInitStruct, &PageError);						// wyczyszczenie strony do zapisu

	for(i = 0; i < SIZE_BUFFER_CFG_DATA; i++)								// zapisanie danych
	{
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, address, buffer[i]);
		address += 2;
	}

	HAL_FLASH_Lock();														// zablokowanie pamieci FLASH
}


void UART_cfg_mode(UART_HandleTypeDef *huart_esp)							// funkcja glowna trybu konfiguracji
{
	uint8_t length;															// dlugosc nadawanej na USB ramki
	uint8_t i;
	uint8_t status = 0;														// status zmiany parametrow w trakcie aktualnego trybu konfiguracji

	for(i = 0; i < 16; i++)													// pobranie SSID i hasla z pamieci FLASH
	{
		cfg_ssid[i] = CFG_DATA_SSID_PTR[i];
		cfg_key[i] = CFG_DATA_KEY_PTR[i];
	}
	for(i = 0; i < 4; i++)													// pobranie adresu IP z pamieci FLASH
	{
		cfg_ip_addr[i] = CFG_DATA_IP_PTR[i];
	}
	cfg_tcp_port = CFG_DATA_PORT_PTR[0];									// pobranie numeru portu TCP z pamieci FLASH
	cfg_multicast_port = CFG_DATA_PORT_PTR[1];								// pobranie numeru portu UDP z pamieci FLASH
	cfg_time = CFG_DATA_TIME[0];											// pobranie czasu oczekiwania na uspienie z pamieci FLASH
	cfg_mode_parameter = none;

	length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "cfg mode\r\n");		// wyslanie informacji o wejsciu w tryb konfiguracji
	while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));

	while(pendant_mode)														// petla glowna trybu konfiguracji
	{
		WatchdogReset();
		pendant_power_save_counter_s = 0;									// reset timera oczekiwania na uspienie
		pendant_power_save_counter_min = 0;

		switch(cfg_mode_parameter)											// sprawdzenie odebranej komendy
		{
		case get_ip:														// odebrano komende "get ip"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "get ip: ");
			length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d.", (int)cfg_ip_addr[0]);
			length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d.", (int)cfg_ip_addr[1]);
			length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d.", (int)cfg_ip_addr[2]);
			length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d\r\n", (int)cfg_ip_addr[3]);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie aktualnego adresu IP
			cfg_mode_parameter = none;
			break;
		}
		case get_ssid:														// odebrano komende "get ssid"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "get ssid: %s\r\n", cfg_ssid);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie aktualnego SSID
			cfg_mode_parameter = none;
			break;
		}
		case get_key:														// odebrano komende "get key"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "get key: %s\r\n", cfg_key);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie aktualnego hasla
			cfg_mode_parameter = none;
			break;
		}
		case get_tcp_port:													// odebrano komende "get tcp port"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "get tcp port: %d\r\n", (int)cfg_tcp_port);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie aktualnego numeru portu TCP
			cfg_mode_parameter = none;
			break;
		}
		case get_udp_port:													// odebrano komende "get udp port"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "get udp port: %d\r\n", (int)cfg_multicast_port);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie aktualnego numeru portu UDP
			cfg_mode_parameter = none;
			break;
		}
		case get_time:														// odebrano komende "get time"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "get time: %d min\r\n", (int)cfg_time);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie aktualnego czasu oczekiwania na uspienie
			cfg_mode_parameter = none;
			break;
		}
		case set_key:														// odebrano komende "set key"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "set key: type key\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia odebrania komendy
			cfg_wait_for_data = STATUS_CHANGE_KEY;							// status oczekiwania na haslo
			cfg_mode_parameter = none;
			break;
		}
		case set_ssid:														// odebrano komende "set ssid"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "set ssid: type ssid\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia odebrania komendy
			cfg_wait_for_data = STATUS_CHANGE_SSID;							// status oczekiwania na SSID
			cfg_mode_parameter = none;
			break;
		}
		case set_ip:														// odebrano komende "set ip"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "set ip: type ip\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia odebrania komendy
			cfg_wait_for_data = STATUS_CHANGE_IP;							// status oczekiwania na adres IP
			cfg_mode_parameter = none;
			break;
		}
		case set_tcp_port:													// odebrano komende "set tcp port"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "set tcp port: type port\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia odebrania komendy
			cfg_wait_for_data = STATUS_CHANGE_TCP_PORT;						// status oczekiwania na numer portu TCP
			cfg_mode_parameter = none;
			break;
		}
		case set_udp_port:													// odebrano komende "set udp port"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "set udp port: type port\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia odebrania komendy
			cfg_wait_for_data = STATUS_CHANGE_UDP_PORT;						// status oczekiwania na numer portu TCP
			cfg_mode_parameter = none;
			break;
		}
		case set_time:														// odebrano komende "set time"
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "set time: type time\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia odebrania komendy
			cfg_wait_for_data = STATUS_CHANGE_TIME;							// status oczekiwania na czas oczekiwania na uspienie
			cfg_mode_parameter = none;
			break;
		}
		case data_key:														// odebrano nowe haslo
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "key: %s\r\n", cfg_key);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie nowego hasla
			status |= STATUS_CHANGE_KEY;									// ustawienie flagi odebrania nowego hasla
			cfg_mode_parameter = none;
			break;
		}
		case data_ssid:														// odebrano nowe SSID
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "ssid: %s\r\n", cfg_ssid);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie nowego SSID
			status |= STATUS_CHANGE_SSID;									// ustawienie flagi odebrania nowego SSID
			cfg_mode_parameter = none;
			break;
		}
		case data_ip:														// odebrano nowy adres IP
		{
			if(get_ip_from_string())										// adres IP poprawny
			{
				length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "ip: ");
				length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d.", (int)cfg_ip_addr[0]);
				length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d.", (int)cfg_ip_addr[1]);
				length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d.", (int)cfg_ip_addr[2]);
				length += (uint8_t)sprintf((char*)(UART_Tx_cfg_buf + length), "%d\r\n", (int)cfg_ip_addr[3]);
				while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));			// wyslanie nowego adresu IP
				status |= STATUS_CHANGE_IP;									// ustawienie flagi odebrania nowego adresu IP
			}
			else															// adres IP bledny
			{
				length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "wrong ip\r\n");
				while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));			// wyslanie informacji o bledzie
			}
			cfg_mode_parameter = none;
			break;
		}
		case data_tcp_port:													// odebrano nowy numer portu TCP
		{
			cfg_tcp_port = (uint16_t)atoi((const char*)cfg_data);			// pobranie nowego numeru portu TCP
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "tcp port: %d\r\n", (int)cfg_tcp_port);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie nowego numeru portu TCP
			status |= STATUS_CHANGE_TCP_PORT;								// ustawienie flagi odebrania nowego numeru portu TCP
			cfg_mode_parameter = none;
			break;
		}
		case data_udp_port:													// odebrano nowy numer portu UDP
		{
			cfg_multicast_port = (uint16_t)atoi((const char*)cfg_data);		// pobranie nowego numeru portu UDP
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "udp port: %d\r\n", (int)cfg_multicast_port);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie nowego numeru portu UDP
			status |= STATUS_CHANGE_UDP_PORT;								// ustawienie flagi odebrania nowego numeru portu UDP
			cfg_mode_parameter = none;
			break;
		}
		case data_time:														// odebrano nowy czas oczekiwania na uspienie
		{
			cfg_time = (uint16_t)atoi((const char*)cfg_data);				// pobranie nowego czasu oczekiwania na uspienie
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "time: %d min\r\n", (int)cfg_time);
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie nowego czasu oczekiwania na uspienie
			status |= STATUS_CHANGE_TIME;									// ustawienie flagi odebrania nowego czasu oczekiwania na uspienie
			cfg_mode_parameter = none;
			break;
		}
		default:
		{
			break;
		}
		}
	}

	WatchdogReset();
	length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "wait for exit\r\n");
	while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));						// wyslanie potweirdzenia komendy wyjscia z trybu konfiguracji
	WatchdogReset();

	if(status & STATUS_CHANGE_IP)											// zmieniono adres IP
	{
		if(ESP_at_cipsta(huart_esp, cfg_ip_addr))							// zapisanie adresu IP w module WiFi
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "ip changed OK\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie potwierdzenia zmiany adresu IP
			WatchdogReset();
		}
		else																// konfiguracja zakonczona niepowodzeniem, prawdopodobnie z powodu wlaczonego DHCP
		{
			length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "ip not changed ERROR\r\n");
			while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));				// wyslanie informacji o bledzie
			status &= ~(STATUS_CHANGE_IP);									// skasowanie flagi zmiany adresu IP
			WatchdogReset();
		}
	}
	if((status & STATUS_CHANGE_SSID) || (status & STATUS_CHANGE_KEY))		// zmieniono SSID lub haslo - konfiguracja modulu ESP
	{
		ESP_at_cwjap(huart_esp, cfg_ssid, cfg_key);							// zapisanie SSID i hasla w module WiFi
		length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "ssid and key changed OK\r\n");
		while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));					// wyslanie potwierdzenia zmiany SSID i hasla
		WatchdogReset();
	}

	pendant_power_save_counter_s = 0;										// reset timera oczekiwania na uspienie
	pendant_power_save_counter_min = 0;

	save_cfg_data(status);													// zapisanie edytowanych parametrow w pamieci FLASH
	length = (uint8_t)sprintf((char*)UART_Tx_cfg_buf, "exit\r\n");
	while(CDC_Transmit_FS(UART_Tx_cfg_buf, length));						// wyslanie informacji o wyjsciu z trybu konfiguracji
	WatchdogReset();
}


