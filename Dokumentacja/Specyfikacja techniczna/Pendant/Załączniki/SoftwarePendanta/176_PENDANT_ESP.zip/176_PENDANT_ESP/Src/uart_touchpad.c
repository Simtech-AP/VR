/*
 * uart_touchpad.c
 *
 *  Created on: 09.05.2020
 */

#include <stdio.h>
#include <string.h>
#include "stm32f1xx_hal.h"
#include "main.h"
#include "uart_touchpad.h"
#include "pendant_defs.h"


uint8_t TOUCHPAD_rx_buf[TOUCHPAD_RX_BUFFER_SIZE];								// bufor odbiorczy
uint8_t TOUCHPAD_switch_frames_buf[TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE][3];		// bufor dla ramek ze stanem przyciskow
uint16_t TOUCHPAD_switch_frames_buf_ind_wr = 0;									// wskaznik do zapisu w buforze ramek ze stanem przyciskow
uint16_t TOUCHPAD_switch_frames_buf_ind_rd = 0;									// wskaznik do odczytu z bufora ramek ze stanem przyciskow
uint8_t TOUCHPAD_touch_frames_buf_in[17];										// bufor dla ramki ze stanem touchpada
volatile uint8_t TOUCHPAD_getOk = 0;											// flaga odebrania potwierdzenia komendy
uint8_t TOUCHPAD_TxFrameBuf[10];												// bufor nadawczy
uint32_t TOUCHPAD_last_rx_time = 0;												// czas ostatniej odebranej ramki

// wyslanie komendy "start" do touchpada
uint8_t TOUCHPAD_turnOn(UART_HandleTypeDef *huart)
{
	uint32_t czas;
	uint8_t len = (uint8_t)sprintf((char*)TOUCHPAD_TxFrameBuf, "start\r");

	HAL_UART_Transmit(huart, TOUCHPAD_TxFrameBuf, len, 100);
	czas = HAL_GetTick();
	HAL_GPIO_WritePin(LED1, 1);
	while(!TOUCHPAD_getOk)													// czekanie na odebranie potwierdzenia
	{
		if(HAL_GetTick() - czas > 100)
		{
			if(HAL_GetTick() > TOUCHPAD_last_rx_time + 70)					// proba ponownego wlaczenie przerwania od odbioru
			{
				HAL_UART_Receive_IT(huart, TOUCHPAD_rx_buf, TOUCHPAD_RX_BUFFER_SIZE);
			}
			HAL_UART_Transmit(huart, TOUCHPAD_TxFrameBuf, len, 100);		// ponowne wyslanie komendy
			czas = HAL_GetTick();
		}
	}
	HAL_GPIO_WritePin(LED2, 1);
	TOUCHPAD_getOk = 0;														// skasowanie flagi odebrania potwierdzenia komendy
	TOUCHPAD_switch_frames_buf_ind_wr = 0;									// czyszczenie bufora ramek ze stanem przyciskow
	TOUCHPAD_switch_frames_buf_ind_rd = 0;

	return 0;
}

uint8_t TOUCHPAD_turnOff(UART_HandleTypeDef *huart)
{
	uint32_t czas;
	uint8_t len = (uint8_t)sprintf((char*)TOUCHPAD_TxFrameBuf, "stop\r");

	HAL_UART_Transmit(huart, TOUCHPAD_TxFrameBuf, len, 100);
	czas = HAL_GetTick();
	HAL_GPIO_WritePin(LED1, 0);
	while(!TOUCHPAD_getOk)													// czekanie na odebranie potwierdzenia
	{
		if(HAL_GetTick() - czas > 100)
		{
			if(HAL_GetTick() > TOUCHPAD_last_rx_time + 70)					// proba ponownego wlaczenie przerwania od odbioru
			{
				HAL_UART_Receive_IT(huart, TOUCHPAD_rx_buf, TOUCHPAD_RX_BUFFER_SIZE);
			}
			HAL_UART_Transmit(huart, TOUCHPAD_TxFrameBuf, len, 100);		// ponowne wyslanie komendy
			czas = HAL_GetTick();
		}
	}
	HAL_GPIO_WritePin(LED2, 0);
	TOUCHPAD_getOk = 0;														// skasowanie flagi odebrania potwierdzenia komendy

	return 0;
}

// inicjalizacja UARTa
void TOUCHPAD_init(UART_HandleTypeDef *huart, TIM_HandleTypeDef *htim)
{
	HAL_UART_Receive(huart, TOUCHPAD_rx_buf, 1, 10);						// wyczyszczenie buforu
	HAL_UART_Receive_IT(huart, TOUCHPAD_rx_buf, TOUCHPAD_RX_BUFFER_SIZE);	// odbieranie po TOUCHPAD_RX_BUFFER_SIZE bajtow
	HAL_TIM_Base_Start_IT(htim);											// wlaczenie timera sterujacego wysylaniem ramki resetujacej watchdoga
}

void TOUCHPAD_UART_RxCallback(UART_HandleTypeDef *huart)
{
	TOUCHPAD_last_rx_time = HAL_GetTick();									// zapisanie czasu ostatniej ramki
	if(!memcmp(TOUCHPAD_rx_buf, "ok\r\n", 4))
	{
		TOUCHPAD_getOk = 1;													// odebranie potwierdzenia
		HAL_UART_Receive_IT(huart, TOUCHPAD_rx_buf, TOUCHPAD_RX_BUFFER_SIZE);
		return;
	}

	if(TOUCHPAD_rx_buf[0] == 255)											// odebranie ramki z danymi
	{
		if(TOUCHPAD_rx_buf[1] == FRAME_TYPE_TOUCH_STATE)					// odebranie ramki ze stanem touchpada
		{
			uint8_t crc = 0, i;

			for(i = 0; i < 16; i++)
				crc ^= TOUCHPAD_rx_buf[i + 1];
			if(crc == TOUCHPAD_rx_buf[i + 1])								// sprawdzenie sumy kontrolnej
			{
				for(i = 0; i < 17; i++)										// przepisanie danych z buforu odbiorczego do buforu na stan touchpada
				{
					TOUCHPAD_touch_frames_buf_in[i] = TOUCHPAD_rx_buf[i + 1];
				}
			}
		}
		else if((TOUCHPAD_rx_buf[1] ^ TOUCHPAD_rx_buf[2]) == TOUCHPAD_rx_buf[3])		// sprawdzenie sumy kontrolnej
		{
			for(uint8_t i = 0; i < 3; i++)												// przepisanie danych z buforu odbiorczego do buforu na stan przyciskow
				TOUCHPAD_switch_frames_buf[TOUCHPAD_switch_frames_buf_ind_wr][i] = TOUCHPAD_rx_buf[i + 1];

			TOUCHPAD_switch_frames_buf_ind_wr++;										// przesuniecie wskaznika do zapisu
			if(TOUCHPAD_switch_frames_buf_ind_wr == TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE)
				TOUCHPAD_switch_frames_buf_ind_wr = 0;

			if(TOUCHPAD_switch_frames_buf_ind_wr == TOUCHPAD_switch_frames_buf_ind_rd)	// przepelnienie bufora
			{
				TOUCHPAD_switch_frames_buf_ind_rd++;									// przesuniecie wskaznika do odczytu
				if(TOUCHPAD_switch_frames_buf_ind_rd == TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE)
					TOUCHPAD_switch_frames_buf_ind_rd = 0;
			}
		}
	}
	HAL_UART_Receive_IT(huart, TOUCHPAD_rx_buf, TOUCHPAD_RX_BUFFER_SIZE);
}

// pobranie ramek ze stanem przycisk�w z bufora
uint16_t TOUCHPAD_waitingSwitchFrames(uint8_t *data)
{
	uint16_t size, j = 0, i;

	if(TOUCHPAD_switch_frames_buf_ind_rd == TOUCHPAD_switch_frames_buf_ind_wr)				// brak ramek do pobrania
		return 0;

	if(TOUCHPAD_switch_frames_buf_ind_rd < TOUCHPAD_switch_frames_buf_ind_wr)				// obliczenie ilosci ramek do pobrania
		size = TOUCHPAD_switch_frames_buf_ind_wr - TOUCHPAD_switch_frames_buf_ind_rd;
	else
		size = TOUCHPAD_switch_frames_buf_ind_wr + TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE - TOUCHPAD_switch_frames_buf_ind_rd;

	for(i = 0; i < size * 3; i++)															// pobranie danych do wyslania
	{
		data[i] = TOUCHPAD_switch_frames_buf[TOUCHPAD_switch_frames_buf_ind_rd][j];
		j++;
		if(j == 3)
		{
			j = 0;
			TOUCHPAD_switch_frames_buf_ind_rd++;
			if(TOUCHPAD_switch_frames_buf_ind_rd == TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE)
				TOUCHPAD_switch_frames_buf_ind_rd = 0;
		}
	}

	return size;																			// zwraca ilosc przyciskow do wyslania
}

// pobranie ramki ze stanem touchpada z bufora
uint16_t TOUCHPAD_waitingTouchFrame(uint8_t *data)
{
	uint8_t i;

	__disable_irq();																		// wylaczenie wszystkich przerwan
	for(i = 0; i < 17; i++)																	// pobranie danych do wyslania
		data[i] = TOUCHPAD_touch_frames_buf_in[i];
	__enable_irq();																			// wlaczenie wszystkich przerwan

	return 0;
}

// wyslanie ramki resetujacej watchdoga touchpada
void TOUCHPAD_watchdog(UART_HandleTypeDef *huart)
{
	uint8_t data = 0;

	HAL_UART_Transmit_IT(huart, &data, 1);
}
