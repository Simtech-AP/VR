/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "usbd_cdc_if.h"
#include "esp_cycl_buf.h"
#include "esp_comm.h"
#include "uart_cfg_mode.h"
#include "modes.h"
#include "battery.h"
#include "uart_touchpad.h"
#include "pendant_defs.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//#define PIERWSZE_URUCHOMIENIE											// odkomentowac przy pierwszym uruchomieniu
#define STYKI_TIMEOUT 50												// czas drgan stykow na wysylanych przyciskach
#define BUFOR_TX_SIZE MAX(TOUCHPAD_SWICTH_FRAMES_BUFFER_SIZE * 3, 80)	// maksymalna dlugosc wysylanej ramki

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

IWDG_HandleTypeDef hiwdg;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

UART_HandleTypeDef *huart_esp = &huart1;								// uart od modulu WiFi
UART_HandleTypeDef *huart_sb = &huart2;									// uart od touchpada
TIM_HandleTypeDef *htim_on_off = &htim1;								// timer od wylacznika
TIM_HandleTypeDef *htim_tp_wdg = &htim2;								// timer od touchpada, power save mode i baterii
TIM_HandleTypeDef *htim_esp_led = &htim3;								// timer od diody WiFi
TIM_HandleTypeDef *htim_chrg_led = &htim4;								// timer od diody ladowania


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_IWDG_Init(void);
static void MX_NVIC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t pendant_mode = PENDANT_MODE_WIFI;								// aktualny tryb pracy pendanta
uint8_t pendant_mode_is_wifi_usb = PENDANT_MODE_WIFIUSB_OFF;			// status wchodzenia w tryb dbg (WiFi + USB)
volatile uint8_t pendant_power_save_counter_ms = 0;						// licznik milisekund do power save mode
volatile uint8_t pendant_power_save_counter_s = 0;						// licznik sekund do power save mode
volatile uint8_t pendant_power_save_counter_min = 0;					// licznik minut do power save mode
uint8_t wait_for_on_off = 0;
uint8_t pendant_is_on = 0;												// flaga wlaczenia pendanta na przycisku
uint8_t usb_is_on = 0;													// flaga podlaczenia USB
uint32_t czas_broadcast;												// czas ostatniego wyslania broadcastu
uint32_t czas_bat;														// czas ostatniego wyslania stanu naladowania akumulatorow
uint32_t czas_dbg;														// czas ostatniego wyslania licznika ramek na USB
uint32_t czas_deadman1 = 0;												// czas drgan stykow deadmana1
uint32_t czas_deadman2 = 0;												// czas drgan stykow deadmana2
uint32_t czas_stop = 0;													// czas drgan stykow estopu
uint32_t czas_touch = 0;												// czas ostatniego wyslania stau touchpada
uint8_t old_stop = 2;													// wczesniejszy stan estopu
uint8_t old_deadman1 = 2;												// wczesniejszy stan deadmana1
uint8_t old_deadman2 = 2;												// wczesniejszy stan deadmana2
uint8_t turned_on = 0;													// flaga polaczenia pendanta z aplikacja
uint8_t length;															// dlugosc ramki
uint8_t bufor[BUFOR_TX_SIZE];											// bufor nadawczy


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if((GPIO_Pin >= GPIO_PIN_1) && (GPIO_Pin <= GPIO_PIN_4))			// przerwanie od przycisniecia deadmanow
	{
		pendant_power_save_counter_s = 0;								// reset czasu do power save mode
		pendant_power_save_counter_min = 0;
	}
	if(GPIO_Pin == UC_BTN_Pin)											// przerwanie od przycisku on/off
	{
		if(HAL_GPIO_ReadPin(UC_BTN) == 0)								// przycisk przycisniety
		{
			htim_on_off->Instance->CNT = 0;
			HAL_TIM_Base_Start_IT(htim_on_off);							// wlaczenie timera od wylacznika
		}
		else															// prszycisk puszczony
		{
			HAL_TIM_Base_Stop_IT(htim_on_off);							// wylaczenie timera od wylacznika
		}
	}
	if(GPIO_Pin == CHRG_STATE_Pin)										// przerwanie od statusu ladnowania
	{
		CHRG_LED_check(pendant_is_on);									// zmiana stanu diody ladowania
		if(HAL_GPIO_ReadPin(CHRG_STATE) == 0)
			HAL_GPIO_WritePin(LED3, 0);
		else
			HAL_GPIO_WritePin(LED3, 1);
	}
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim_tp_wdg == htim)												// timer dziala przez caly czas wlaczenia pendanta na przycisku
	{
		pendant_power_save_counter_ms++;								// co 50 ms, 1s == 20
		if(pendant_power_save_counter_ms == 20)
		{
			pendant_power_save_counter_ms = 0;
			pendant_power_save_counter_s++;								// inkrementacja licznika sekund
			if(pendant_power_save_counter_s == 60)
			{
				pendant_power_save_counter_s = 0;
				pendant_power_save_counter_min++;						// inkrementacja licznika minut
				if(CFG_DATA_TIME[0])									// czas power save mode ustawiony na 0 - tryb nie dziala
				{
					if(pendant_power_save_counter_min == CFG_DATA_TIME[0])
					{
						HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_1);	// wylaczenie diody WiFi
						HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_2);
						HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_3);
						BATTERY_turn_off();								// wylaczenie pendanta
					}
				}
			}
		}
		TOUCHPAD_watchdog(huart_sb);									// reset touchpada co 50 ms
		CHRG_LED_check(pendant_is_on);									// aktualizacja stanu diody ladowania co 50 ms
		return;
	}
	if(htim == htim_chrg_led)											// timer diody ladowania
	{
		HAL_GPIO_TogglePin(EXT2_GREEN);									// w stanach migajacych miga wyjsciem diody zielonej,
		return;															// wyjscie diody czerwonej ustawia kolor migania
	}
	if(htim == htim_on_off)												// timer od przycisku on/off
	{
		if(wait_for_on_off)												// zapobiega zbyt wczesnemu wywolania callbacka
		{
			if(pendant_is_on)											// jesli pendant jest wlaczony
			{
				HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_1);			// wylaczenie diody WiFi
				HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_2);
				HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_3);
				BATTERY_turn_off();										// wylaczenie pendanta
			}
			else														// jesli pendant jest wylaczony
			{
				pendant_is_on = 1;										// ustawienie flagi wlaczenia
			}
		}
	}
}


void turningOn()														// proces wlaczania pendanta
{
	if(HAL_GPIO_ReadPin(CHRG_STATE) == 0)
		HAL_GPIO_WritePin(LED3, 0);
	else
		HAL_GPIO_WritePin(LED3, 1);

	HAL_TIM_Base_Start_IT(htim_on_off);									// wlaczenie, wylaczenie i flaga zapobiegaja
	HAL_TIM_Base_Stop_IT(htim_on_off);									// zbyt wczesnemu wywolaniu callbacka
	wait_for_on_off = 1;

	RCC->APB1ENR |= RCC_APB1ENR_PWREN;									// wlaczenie zebara pozwalajacego na odczytanie flagi resetu programowego
	if((RCC->CSR & RCC_CSR_SFTRSTF) == 0)								// pendant wlaczony bez resetu programowego
	{
		if(HAL_GPIO_ReadPin(UC_BTN) == 0)								// pendant wlaczony z przycisku bez USB
		{
			HAL_Delay(1000);											// jest procesor jest wlaczony po 1 s
			pendant_is_on = 1;											// nastepuje wlaczenie pendanta
		}
		else															// podlaczenie USB, pendant wylaczony
		{
			usb_is_on = 1;												// ustawienie flagi podlaczenia USB
			CHRG_LED_check(0);											// aktualizacja diody ladowania
			while(!pendant_is_on);										// oczekiwanie na wlaczenie pendanta przyciskiem
		}
	}
	else 																// wystapil reset programowy: pendant wylaczony w trakcie ladowania
	{
		usb_is_on = 1;													// ustawienie flagi podlaczenia USB
		CHRG_LED_check(0);												// aktualizacja diody ladowania
		while(!pendant_is_on);											// oczekiwanie na wlaczenie pendanta przyciskiem
	}
	HAL_GPIO_WritePin(UC_ON, 1);										// wlaczenie pendanta
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);							// wlaczenie diody WiFi
	ADC_init(&hadc1, &hdma_adc1);										// inicjalizacja ADC
	if(usb_is_on == 1)													// aktualizacja diody ladowania
	{
		if(HAL_GPIO_ReadPin(CHRG_STATE) == GPIO_PIN_RESET)
			CHRG_LED_change(battery_charging);
		else
			CHRG_LED_change(pendant_on);
	}
	else
		CHRG_LED_change(pendant_on);
}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart == huart_sb)												// odebranie ramki z touchpada
		TOUCHPAD_UART_RxCallback(huart);
}


void WatchdogReset()													// funkcja resetujaca watchdoga
{
	HAL_IWDG_Refresh(&hiwdg);
}


void main_send_sample()													// funkcja wysylajaca komplet danych
{
	uint8_t tmp;

	WatchdogReset();
	pendant_power_save_counter_min = 0;									// reset timera power save mode
	pendant_power_save_counter_s = 0;

	if(!turned_on)														// jesli pendant nie byl polaczony z aplikacja
	{
		TOUCHPAD_turnOn(huart_sb);										// wlaczenie touchpada
		turned_on = 1;													// ustawienie flagi polaczenia
		old_deadman1 = HAL_GPIO_ReadPin(DEADMAN1);						// zapisanie pierwszego stanu deadmana1
		old_deadman2 = HAL_GPIO_ReadPin(DEADMAN2);						// zapisanie pierwszego stanu deadmana2
		old_stop = HAL_GPIO_ReadPin(STOP);								// zapisanie pierwszego stanu estopu
		// wyslanie stanow przyciskow
		PendantSend_button(pendant_mode, BUTTON_NO(old_deadman1), BUTTON_DEADMAN1);
		PendantSend_button(pendant_mode, BUTTON_NO(old_deadman2), BUTTON_DEADMAN2);
		PendantSend_button(pendant_mode, BUTTON_NC(old_stop), BUTTON_STOP);
	}

	WatchdogReset();

	if(HAL_GetTick() - czas_bat > 2000)									// wyslanie stanu naladowania baterii
	{
		czas_bat = HAL_GetTick();
		PendantSend_battery(pendant_mode, BATTERY_get_percentage());
	}

	if(HAL_GetTick() - czas_dbg > 1000)									// wyslanie licznika ramek
	{
		czas_dbg = HAL_GetTick();
		if(pendant_mode != PENDANT_MODE_USB)							//oprocz trybu USB
		{
			length = (uint8_t)sprintf((char*)bufor, "Sent: %d\r\n", (int)ESP_get_send_frames_counter());
			CDC_Transmit_FS(bufor, length);
		}
	}

	if(HAL_GetTick() - czas_deadman1 > STYKI_TIMEOUT)					// wyslanie stanu deadmana1
	{
		tmp = HAL_GPIO_ReadPin(DEADMAN1);
		if(tmp != old_deadman1)
		{
			czas_deadman1 = HAL_GetTick();
			old_deadman1 = tmp;
			PendantSend_button(pendant_mode, BUTTON_NO(old_deadman1), BUTTON_DEADMAN1);
		}
	}

	if(HAL_GetTick() - czas_deadman2 > STYKI_TIMEOUT)					// wyslanie stanu deadmana2
	{
		tmp = HAL_GPIO_ReadPin(DEADMAN2);
		if(tmp != old_deadman2)
		{
			czas_deadman2 = HAL_GetTick();
			old_deadman2 = tmp;
			PendantSend_button(pendant_mode, BUTTON_NO(old_deadman2), BUTTON_DEADMAN2);
		}
	}

	if(HAL_GetTick() - czas_stop > STYKI_TIMEOUT)						// wyslanie stanu estopu
	{
		tmp = HAL_GPIO_ReadPin(STOP);
		if(tmp != old_stop)
		{
			czas_stop = HAL_GetTick();
			old_stop = tmp;
			PendantSend_button(pendant_mode, BUTTON_NC(old_stop), BUTTON_STOP);
		}
	}

	if(HAL_GetTick() - czas_touch > 50)									// wyslanie stanu touchpada
	{
		czas_touch = HAL_GetTick();
		TOUCHPAD_waitingTouchFrame(bufor);								// pobranie ramki z bufora touchpada
		PendantSend_touch(pendant_mode, bufor);							// wyslanie ramki przez WiFi
	}

	tmp = TOUCHPAD_waitingSwitchFrames(bufor);							// sprawdzenie oczekujacych ramek ze stanem switchboarda
	if(tmp)
		PendantSend_switch(pendant_mode, bufor, (uint16_t)tmp);			// wyslanie ramek switchboarda

	if(pendant_mode == PENDANT_MODE_USB)								// sprawdzenie odebrania polecenia
		tmp = UART_check_binaryRx_frame();
	else
		tmp = ESP_check_binaryRx_frame();

	if(tmp == PENDANT_TRACKER_CHRG_ID)									// odebranie polecenia ladowania trackera
		TRACKER_chrg_on();
	else if(tmp == PENDANT_TRACKER_NCHRG_ID)							// odebranie polecenia wylaczenia ladowania trackera
		TRACKER_chrg_off();

	if(pendant_mode != PENDANT_MODE_USB)								// poza trybem USB
	{
		switch(tmp)														// reakcja na zapytanie:
		{
		case PENDANT_DBG_ID_NONE:
			break;
		case PENDANT_DBG_ID_RSSI:										// o sile sygnalu
		{
			length = ESP_at_cwjap_ask(huart_esp, bufor);
			PendantSend_dbg_rrsi(pendant_mode, bufor, length);
			break;
		}
		case PENDANT_DBG_ID_SSID:										// o nazwe sieci
		{
			length = ESP_at_cwjap_ask(huart_esp, bufor);
			PendantSend_dbg_ssid(pendant_mode, bufor, length);
			break;
		}
		case PENDANT_DBG_ID_BAT_V:										// o napiecie na akumulatorach
		{
			PendantSend_dbg_bat(pendant_mode, BATTERY_get_voltage());
			break;
		}
		case PENDANT_DBG_ID_FRM_CNT:									// o licznik ramek
		{
			PendantSend_dbg_cnt(pendant_mode, ESP_get_send_frames_counter());
			break;
		}
		case PENDANT_DBG_ID_MAC:										// o adres MAC sieci
		{
			length = ESP_at_cwjap_ask(huart_esp, bufor);
			PendantSend_dbg_mac(pendant_mode, bufor, length);
			break;
		}
		}
	}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint8_t stat = 0;													// status polaczenia z WiFi i aplikacja
	uint16_t tcp_port = CFG_DATA_PORT_PTR[0];							// numer portu TCP
	uint16_t multicast_port = CFG_DATA_PORT_PTR[1];						// numer portu UDP
	uint8_t *ip_addr = CFG_DATA_IP_PTR;									// adres IP
  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	PWR->CR |= PWR_CR_PLS_LEV7 | PWR_CR_PVDE;							// procesor nie wlacza sie przy napieciu ponizej 2,9 V
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
#if 0																	// define zwiazane z generatorem CubeMX
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  MX_USB_DEVICE_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_IWDG_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();
  /* USER CODE BEGIN 2 */
#endif
	MX_GPIO_Init();														// inicjalizacja wszystkich peryferiow z CubeMX poza watchdogiem
	MX_DMA_Init();
	MX_USART1_UART_Init();
	MX_USART2_UART_Init();
	MX_ADC1_Init();
	MX_USB_DEVICE_Init();
	MX_TIM3_Init();
	MX_TIM4_Init();
	MX_TIM1_Init();
	MX_TIM2_Init();
	MX_NVIC_Init();

	turningOn();														// proces wlaczania pendanta
	HAL_GPIO_WritePin(ESP_ON, 0);										// wlaczenie modulu WiFi
	ESP_reset(huart_esp);												// reset modulu WiFi
	PendantModes_init(ip_addr);											// inicjalizacja buforow nadawczych pendanta
	TOUCHPAD_init(huart_sb, htim_tp_wdg);								// inicjalizacja polaczenia z touchpadem

#ifdef PIERWSZE_URUCHOMIENIE											// ponizsze funkcje wystarczy wykonac tylko podczas pierwszego uruchomienia
	ESP_at_cwmode(huart_esp);											// modul w trybie stacji
	ESP_at_cwdhcp(huart_esp);											// wylaczenie DHCP
#endif

	czas_broadcast = HAL_GetTick();
	czas_bat = HAL_GetTick();
	czas_dbg = HAL_GetTick();
	HAL_Delay(200);
	MX_IWDG_Init();														// inicjalizacja watchdoga
	while(1)															// petla glowna pendanta
	{
		if(pendant_mode == PENDANT_MODE_CFG)							// wejscie w tryb konfiguracji
		{
			if(turned_on)												// wylaczenie touchpada jesli byl wlaczony
			{
				TOUCHPAD_turnOff(huart_sb);
				turned_on = 0;
			}
			WatchdogReset();
			ESP_reset(huart_esp);										// reset modulu WiFi, aby umozliwic edycje ustawien
			WatchdogReset();
			UART_cfg_mode(huart_esp);									// funkcja glowna trybu konfiguracji
			tcp_port = CFG_DATA_PORT_PTR[0];							// aktualizacja numerow portow
			multicast_port = CFG_DATA_PORT_PTR[1];
			ESP_reset(huart_esp);										// ponowny reset modulu WiFi
			WatchdogReset();
		}

		if(pendant_mode == PENDANT_MODE_USB)							// wejscie w tryb USB
		{
			ESP_off();													// wylaczenie modulu WIFi
			WatchdogReset();
			while(pendant_mode == PENDANT_MODE_USB)						// dopoki pendant jest w trybie USB
			{
				main_send_sample();										// wysylanie kompetu danych
				WatchdogReset();
			}
			length = (uint8_t)sprintf((char*)bufor, "exit\r\n");		// wyslanie potwierdzenia wyjscia z trybu USB
			while(CDC_Transmit_FS(bufor, length));
			WatchdogReset();
			turned_on = 0;
			TOUCHPAD_turnOff(huart_sb);									// wylaczenie touchpada
			ESP_reset(huart_esp);										// wlaczenie modulu WiFi
			WatchdogReset();
		}

		stat = ESP_update(huart_esp);									// aktualizacja statusu polaczenia WIFI
		if(stat & ESP_CONN_STAT_WIFI_IP)								// pendant polaczony z wifi
		{
			if(stat & ESP_CONN_STAT_SIMTECH)							// pendant polaczony z aplikacja
			{
				main_send_sample();										// wyslanie kompletu danych
			}
			else														// pendant niepolaczony z aplikacja
			{
				if(turned_on)											// jesli aplikacja byla polaczona
				{
					turned_on = 0;										// skasowanie flagi
					TOUCHPAD_turnOff(huart_sb);							// wylaczenie touchpada
					WatchdogReset();
				}
				else													// jesli aplikacja nie byla polaczona
				{
					if(!(stat & ESP_CONN_STAT_TCP_OPEN))				// jesli gniazdo TCP nie jest otwarte
					{
						ESP_at_cipserver(huart_esp, tcp_port);			// otwarcie servera TCP
						WatchdogReset();
					}
					if(stat & ESP_CONN_STAT_BROAD_OPEN)					// jesli gniazdo UDP jest otwarte
					{
						if(HAL_GetTick() - czas_broadcast > 250)		// i uplynal odpowiedni czas
						{
							czas_broadcast = HAL_GetTick();
							PendantSend_broadcast(pendant_mode);		// wysylanie multicasta
						}
					}
					else												// jesli gniazdo UDP nie jest otwarte
					{
						ESP_at_cipstart(huart_esp, multicast_port);		// otwarcie gniazda UDP
						WatchdogReset();
					}
				}
			}
			if(pendant_mode_is_wifi_usb == PENDANT_MODE_WIFIUSB_ENTER)			// jesli pendant otrzymal polecenie wejscia w tryb DBG
			{
				length = ESP_at_cwjap_ask(huart_esp, bufor);					// pobranie parametrow sieci
				WatchdogReset();
				bufor[length] = ',';
				length++;
				length += ESP_at_cipstamac_ask(huart_esp, bufor + length);		// pobranie adresu MAC
				WatchdogReset();
				length += (uint8_t)sprintf((char*)(bufor + length), ",%d.%d.%d.%d\r\n", (int)(CFG_DATA_IP_PTR[0]), (int)(CFG_DATA_IP_PTR[1]), (int)(CFG_DATA_IP_PTR[2]), (int)(CFG_DATA_IP_PTR[3]));
				CDC_Transmit_FS(bufor, length);									// wyslanie parametrow sieci i pendanta
				WatchdogReset();
				pendant_mode_is_wifi_usb = PENDANT_MODE_WIFIUSB_ON;				// ustawienie statusu wlaczenia trybu DBG
			}
		}
		else										// pendant rozlaczony z wifi
		{
			WatchdogReset();
			if(turned_on)							// jesli pendant byl polaczony z aplikacja
			{
				turned_on = 0;
				TOUCHPAD_turnOff(huart_sb);			// wylaczenie touchpada
				WatchdogReset();
			}
		}
		TRACKER_check_timeout();					// sprawdzenie timeoutu ladowania trackera
	}


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC|RCC_PERIPHCLK_USB;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV8;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief NVIC Configuration.
  * @retval None
  */
static void MX_NVIC_Init(void)
{
  /* USART1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(USART1_IRQn);
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_AnalogWDGConfTypeDef AnalogWDGConfig = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */
  /** Common config 
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 2;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analog WatchDog 1 
  */
  AnalogWDGConfig.WatchdogMode = ADC_ANALOGWATCHDOG_SINGLE_REG;
  AnalogWDGConfig.HighThreshold = 0;
  AnalogWDGConfig.LowThreshold = 0;
  AnalogWDGConfig.Channel = ADC_CHANNEL_10;
  AnalogWDGConfig.ITMode = DISABLE;
  if (HAL_ADC_AnalogWDGConfig(&hadc1, &AnalogWDGConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  sConfig.Channel = ADC_CHANNEL_10;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel 
  */
  sConfig.Channel = ADC_CHANNEL_11;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief IWDG Initialization Function
  * @param None
  * @retval None
  */
static void MX_IWDG_Init(void)
{

  /* USER CODE BEGIN IWDG_Init 0 */

  /* USER CODE END IWDG_Init 0 */

  /* USER CODE BEGIN IWDG_Init 1 */

  /* USER CODE END IWDG_Init 1 */
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
  hiwdg.Init.Reload = 4095;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IWDG_Init 2 */

  /* USER CODE END IWDG_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 4800-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 20000-1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 4800 - 1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 500 - 1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000 - 1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 100 - 1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 48000-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 500-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, UC_ON_Pin|LED3_Pin|TRACKER_EN_Pin|LED1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, ESP_ON_Pin|ESP_EN_Pin|ESP_RST_Pin|USB33_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ESP_GPIO15_GPIO_Port, ESP_GPIO15_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(V5EN_GPIO_Port, V5EN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, EXT1_RED_Pin|EXT2_GREEN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : UC_BTN_Pin */
  GPIO_InitStruct.Pin = UC_BTN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(UC_BTN_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : UC_ON_Pin */
  GPIO_InitStruct.Pin = UC_ON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(UC_ON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LED3_Pin TRACKER_EN_Pin V5EN_Pin LED1_Pin */
  GPIO_InitStruct.Pin = LED3_Pin|TRACKER_EN_Pin|V5EN_Pin|LED1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : ESP_ON_Pin ESP_GPIO15_Pin ESP_RST_Pin */
  GPIO_InitStruct.Pin = ESP_ON_Pin|ESP_GPIO15_Pin|ESP_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : ESP_EN_Pin USB33_Pin */
  GPIO_InitStruct.Pin = ESP_EN_Pin|USB33_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : STOP_Pin */
  GPIO_InitStruct.Pin = STOP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(STOP_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DEADMAN1_Pin DEADMAN2_Pin DEADMAN3_Pin DEADMAN4_Pin */
  GPIO_InitStruct.Pin = DEADMAN1_Pin|DEADMAN2_Pin|DEADMAN3_Pin|DEADMAN4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PC11 */
  GPIO_InitStruct.Pin = GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LED2_Pin */
  GPIO_InitStruct.Pin = LED2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : CHRG_STATE_Pin */
  GPIO_InitStruct.Pin = CHRG_STATE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(CHRG_STATE_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : EXT1_RED_Pin EXT2_GREEN_Pin */
  GPIO_InitStruct.Pin = EXT1_RED_Pin|EXT2_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure peripheral I/O remapping */
  __HAL_AFIO_REMAP_USART3_PARTIAL();

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

  HAL_NVIC_SetPriority(EXTI3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
