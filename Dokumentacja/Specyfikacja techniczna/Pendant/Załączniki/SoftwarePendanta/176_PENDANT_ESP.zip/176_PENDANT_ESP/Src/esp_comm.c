/*
 * esp_comm.c
 *
 *  Created on: 11.10.2019
 */

#include <stdio.h>
#include <string.h>
#include "stm32f1xx_hal.h"
#include "main.h"
#include "esp_cycl_buf.h"
#include "esp_comm.h"
#include "pendant_defs.h"
#include "usbd_cdc_if.h"


uint8_t UART_Tx_at_buf[50];																	// bufor nadawczy
uint8_t UART_Rx_msg[CYCLICAL_BUFFER_SIZE];													// bufor odbiorczy - zawiera ramke odczytana z bufora cyklicznego
esp_socket_status_enum socket_list[SOCKET_LIST_SIZE];										// statusy poszczegolnych gniazd (id gniazda = indeks w tablicy)
uint8_t ESP_connected_status = ESP_CONN_STAT_WIFI_DISCONN;									// status polaczenia z WiFi i aplikacja
uint8_t ESP_broadcast_id = SOCKET_LIST_SIZE;												// id gdziazda UDP
uint8_t ESP_tcp_id = SOCKET_LIST_SIZE;														// id gniazda TCP
uint8_t ESP_dbg_frame_id = PENDANT_DBG_ID_NONE;												// id odebranego polecenia
uint32_t ESP_send_frames_counter = 0;														// licznik wyslanych ramek
volatile uint8_t tx_flag = 0;																// flaga zakonczenia wysylania wiadomosci
extern TIM_HandleTypeDef *htim_esp_led;														// timer obslugujacy PWM diody led


void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)										// zakonczenie wysylania danych z przerwaniem
{
	tx_flag = 1;
}


void change_led()																			// zmiana led
{
	uint8_t state;

	if(ESP_connected_status & ESP_CONN_STAT_WIFI_CONN)
	{
		if(ESP_connected_status & ESP_CONN_STAT_SIMTECH)
			state = ESP_CONN_STAT_SIMTECH;
		else
			state = ESP_CONN_STAT_WIFI_CONN;
	}
	else
		state = ESP_CONN_STAT_WIFI_DISCONN;

	switch(state)
	{
	case ESP_CONN_STAT_WIFI_DISCONN:														// czerwony
	{
		HAL_TIM_PWM_Start(htim_esp_led, TIM_CHANNEL_1);										// czerwony on
		HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_2);										// zielony off
		HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_3);										// niebieski off
		return;
	}
	case ESP_CONN_STAT_WIFI_CONN:															// niebieski
	{
		HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_1);										// czerwony off
		HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_2);										// zielony off
		HAL_TIM_PWM_Start(htim_esp_led, TIM_CHANNEL_3);										// niebieski on
		return;
	}
	case ESP_CONN_STAT_SIMTECH:																// zielony
	{
		HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_1);										// czerwony off
		HAL_TIM_PWM_Start(htim_esp_led, TIM_CHANNEL_2);										// zielony on
		HAL_TIM_PWM_Stop(htim_esp_led, TIM_CHANNEL_3);										// niebieski off
		return;
	}
	}
}


void send_ack_time(uint32_t time)															// wyslanie dlugiego czasu oczekiwania na ACK
{
	uint8_t ubs_bufor[20], usb_len;

	time = HAL_GetTick() - time;
	if(time > 60)																			// czas dluzszy niz 60 ms
	{
		usb_len = (uint8_t)sprintf((char*)ubs_bufor, "\t\t\ttime: %d\r\n", (int)(time));
		CDC_Transmit_FS(ubs_bufor, usb_len);
	}
}


uint8_t check_ready(uint8_t *buf)															// sprawdzenie statusu "ready"
{
	if(!memcmp(buf, "ready\r", 6))
		return 1;

	return 0;
}


esp_cmd_status_enum check_cmd_status(uint8_t *buf)											// sprawdzenie statusu wykonania komendy
{
	if(!memcmp(buf, "ERROR\r", 6))
		return cmd_error;

	if(!memcmp(buf, "OK\r", 3))
		return cmd_ok;

	return cmd_none;
}


uint8_t check_CWJAP(uint8_t *buf, uint8_t *out)												// sprawdzenie odebrania odpowiedzi na CWJAP
{
	uint8_t len = 0;

	if(memcmp(buf, "+CWJAP:", 7))
		return 0;

	while((buf[len + 7] != 13) && (len + 7 < CYCLICAL_BUFFER_SIZE))
	{
		out[len] = buf[len + 7];															// przepisanie odpowiedzi
		len++;
	}

	return len;																				// zwraca dlugosc odpowiedzi
}


uint8_t check_CIPSTAMAC(uint8_t *buf, uint8_t *out)											// sprawdzenie odebrania odpowiedzi na CIPSTAMAC
{
	uint8_t len = 0;

	if(memcmp(buf, "+CIPSTAMAC:", 11))
		return 0;

	while((buf[len + 11] != 13) && (len + 11 < CYCLICAL_BUFFER_SIZE))
	{
		out[len] = buf[len + 11];															// przepisanie odpowiedzi
		len++;
	}

	return len;																				// zwraca dlugosc odpowiedzi
}


uint32_t ESP_get_send_frames_counter()														// pobranie licznika wyslanych ramek
{
	return ESP_send_frames_counter;
}


uint8_t check_SimtechHELLO(uint8_t *buf, uint8_t len)										// sprawdzenie odebrania SimtechHELLO
{
	uint8_t start;

	if(len < 24)
		return 0;

	start = len - 24;

	if(memcmp(buf + start, "+IPD,", 5))
		return 0;

	if(buf[5 + start] != '0' + ESP_tcp_id)
		return 0;

	if(memcmp(buf + start + 6, ",14:SimtechHELLO\r", 17))
		return 0;

	ESP_connected_status |= ESP_CONN_STAT_SIMTECH;
	change_led();																			// zmiana led na zielony

	return 1;
}


uint8_t check_dbg_frame(uint8_t *buf, uint8_t len)											// odczytanie polecenia z odebranej wiadomosci
{
	if(len < 14)
		return 0;

	buf = buf + len - 14;

	if(memcmp(buf, "+IPD,", 5))
		return 0;

	if(buf[5] != '0' + ESP_tcp_id)
		return 0;

	if(memcmp(buf + 6, ",3:", 3))
		return 0;

	if(buf[9] != buf[10])
		return 0;																			// sprawdzenie crc

	if(buf[11] != 13)																		// sprawdzenie konca wiadomosci
		return 0;

	if((buf[9] >= PENDANT_DBG_ID_FIRST) && (buf[9] <= PENDANT_DBG_ID_LAST))					// zapisanie odebranej komendy: zapytanie dbg
	{
		ESP_dbg_frame_id = buf[9];
		return 1;
	}

	if((buf[9] == PENDANT_TRACKER_CHRG_ID) || (buf[9] == PENDANT_TRACKER_NCHRG_ID))			// zapisanie odebranej komendy: wlaczenie / wylaczenie trackera
	{
		ESP_dbg_frame_id = buf[9];
		return 1;
	}
	return 0;
}


uint8_t ESP_check_binaryRx_frame()															// sprawdzenie odebrania polecenia
{
	uint8_t tmp = ESP_dbg_frame_id;

	ESP_dbg_frame_id = PENDANT_DBG_ID_NONE;													// wyzerowanie nowego polecenia

	return tmp;
}


uint8_t check_SEND_OK(uint8_t *buf)															// sprawdzenie statusu wyslania wiadomosci
{
	if(!memcmp(buf, "SEND OK\r", 8))
		return 1;

	if(!memcmp(buf, "SEND FAIL\r", 10))
		return 2;

	return 0;
}


esp_socket_status_enum check_socket_status(uint8_t *buf, uint8_t len)						// sprawdzenie zmiany statusu gniazda
{
	uint8_t start;																			// poczatek sprawdzanej wiadomosci
	uint8_t id;

	if(len < 10)																			// wiadomosc za krotka
		return 0;
	start = len - 10;

	if(!memcmp(buf + start + 1, ",CLOSED\r", 8))
	{
		id = buf[start] - '0';
		if(id > 9)
			return socket_none;

		socket_list[id] = socket_closed;
		if(id == ESP_broadcast_id)															// zamkniecie gniazda broadcastu
		{
			ESP_connected_status &= ~ESP_CONN_STAT_BROAD_OPEN;
			ESP_broadcast_id = SOCKET_LIST_SIZE;
		}
		else if(id == ESP_tcp_id)															// zamkniecie gniazda TCP
		{
			ESP_connected_status &= ~(ESP_CONN_STAT_TCP_OPEN | ESP_CONN_STAT_TCP_CONN | ESP_CONN_STAT_SIMTECH);
			change_led();																	// zmiana led
			ESP_tcp_id = SOCKET_LIST_SIZE;
		}
		return socket_closed;
	}

	if(len < 11)
		return 0;
	start = len - 11;

	if(!memcmp(buf + start + 1, ",CONNECT\r", 9))
	{
		id = buf[start] - '0';
		if(id > 9)
			return socket_none;

		socket_list[id] = socket_connect;
		if(id == ESP_broadcast_id)															// polaczenie gniazda broadcastu
			ESP_connected_status |= ESP_CONN_STAT_BROAD_OPEN;
		else if(id == ESP_tcp_id)															// polaczenie gniazda TCP
			ESP_connected_status |= ESP_CONN_STAT_TCP_CONN;
		else																				// polaczenie gniazda TCP i zapisanie nowego id
		{
			ESP_tcp_id = id;
			ESP_connected_status |= ESP_CONN_STAT_TCP_CONN;
		}
		return socket_connect;
	}

	if(len < 16)
		return 0;
	start = len - 16;

	if(!memcmp(buf + start + 1, ",CONNECT FAIL\r", 14))
	{
		id = buf[start] - '0';
		if(id > 9)
			return socket_none;

		socket_list[id] = socket_connect_fail;
		if(id == ESP_tcp_id)																// blad polaczenia gniazda TCP
		{
			ESP_connected_status &= ~(ESP_CONN_STAT_TCP_CONN | ESP_CONN_STAT_SIMTECH);
			change_led();
		}
		return socket_connect_fail;
	}

	return socket_none;
}


esp_wifi_status_enum check_wifi_status(uint8_t *buf, uint8_t len)							// sprawdzenie zmiany statusu polaczenia WiFi
{
	if(len < 13)
		return 0;

	if(!memcmp(buf + len - 13, "WIFI GOT IP\r", 12))
	{
		ESP_connected_status |= ESP_CONN_STAT_WIFI_IP;
		change_led();																		// zmiana led na niebieski po nadaniu IP
		return wifi_got_ip;
	}

	if(len < 16)
		return 0;

	if(!memcmp(buf + len - 16, "WIFI CONNECTED\r", 15))
	{
		ESP_connected_status |= ESP_CONN_STAT_WIFI_CONN;
		return wifi_connected;
	}

	if(len < 17)
		return 0;

	if(!memcmp(buf + len - 17, "WIFI DISCONNECT\r", 16))
	{
		ESP_connected_status &= ~(ESP_CONN_STAT_WIFI_CONN | ESP_CONN_STAT_WIFI_IP);
		change_led();																		// zmiana led na czerwony
		return wifi_disconnected;
	}

	return wifi_none;
}


uint8_t wait_for_msg()																		// sprawdzenie nowej wiadomosci w buforze cyklicznym
{
	uint8_t length, i;

	if(CYCL_BUF_check_new_frame_flag())
	{
		length = CYCL_BUF_check_frame_length();												// pobranie dlugosci wiadomosci
		for(i = 0; i < length; i++)
		{
			UART_Rx_msg[i] = CYCL_BUF_get_data();											// pobranie tresci wiadomosci
		}

		return length;																		// zwraca dlugosci wiadomosci
	}

	return 0;																				// brak wiadomosci: dlugosc == 0
}


void ESP_update_status(uint8_t *buf, uint8_t len)											// aktualizacja statusu polaczenia
{
	if(check_socket_status(UART_Rx_msg, len) == socket_none)								// sprawdzenie statusu gniazda
		check_wifi_status(UART_Rx_msg, len);												// jesli wiadomosc nie dotyczy zadnego gniazda sprawdzenie statusu polaczenia z siecia
	if(!(ESP_connected_status & ESP_CONN_STAT_SIMTECH))										// jesli nie ma polaczenia z aplikacja
		check_SimtechHELLO(UART_Rx_msg, len);												// sprawdza SimtechHELLO
	else																					// jesli jest polaczenie z aplikacja
		check_dbg_frame(UART_Rx_msg, len);													// sprawdza odebranie komendy
}


uint8_t ESP_update(UART_HandleTypeDef *huart)												// sprawdzenie dostepnosci nowej ramki i aktualizacja statusu polaczenia
{
	uint8_t length;

	length = wait_for_msg();
	while(length)
	{
		ESP_update_status(UART_Rx_msg, length);												// aktualizacja statusu polaczenia
		length = wait_for_msg();
	}

	return ESP_connected_status;															// zwraca status polaczenia
}


// wyslanie komendy i czekanie na odpowiedz modulu WiFi
uint8_t ESP_at_command_set(UART_HandleTypeDef *huart, uint8_t *data, uint8_t size, uint16_t timeout)
{
	uint32_t time;
	uint8_t length;

	__disable_irq();
	HAL_UART_Transmit(huart, data, size, 100);												// wyslanie komendy
	__enable_irq();

	time = HAL_GetTick();
	while(time + timeout > HAL_GetTick())													// wystapienie timeoutu okreslonego przez parametr
	{
		length = wait_for_msg();
		if(length)
		{
			switch(check_cmd_status(UART_Rx_msg))											// sprawdzenie statusu wykonania komendy
			{
			case cmd_ok:																	// komenda zakonczona powodzeniem
				return 1;
			case cmd_error:																	// komenda zakonczona bledem
				return 0;
			default:
				ESP_update_status(UART_Rx_msg, length);										// aktualizacja statusu polaczenia
			}
		}
	}

	return 0;
}


uint8_t ESP_at_cipsta(UART_HandleTypeDef *huart, uint8_t *ip)								// wyslanie komendy CIPSTA - ustawienie statycznego adresu IP
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPSTA=\"%d.%d.%d.%d\"\r\n", (int)ip[0], (int)ip[1], (int)ip[2], (int)ip[3]);

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_cwjap(UART_HandleTypeDef *huart, char *ssid, char *key)						// wyslanie komendy CWJAP - ustawienie nazwy i hasla sieci
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, key);

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_cwdhcp(UART_HandleTypeDef *huart)											// wyslanie komendy CWDHCP - wylaczenie DHCP
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CWDHCP=1,0\r\n");

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_cwmode(UART_HandleTypeDef *huart)											// wyslanie komendy CWMODE - wejscie w tryb stacji
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CWMODE=1\r\n");

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_echo_off(UART_HandleTypeDef *huart)											// wyslanie komendy ATE0 - wylaczenie echa
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "ATE0\r\n");

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_cipmux(UART_HandleTypeDef *huart)											// wyslanie komendy CIPMUX - wejscie w tryb multiple connections
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPMUX=1\r\n");

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_cwjap_ask(UART_HandleTypeDef *huart, uint8_t *out)							// wyslanie zapytania CWJAP - pobranie informacji o sieci WiFi
{
	uint8_t length;
	uint8_t ans_len = 0;																	// dlugosc odpowiedzi
	uint32_t time;

	length = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CWJAP?\r\n");

	tx_flag = 0;
	time = HAL_GetTick();
	HAL_UART_Transmit_IT(huart, UART_Tx_at_buf, length);									// wyslanie komendy zapytania
	while(!tx_flag)																			// oczekiwanie na wyslanie
		if(HAL_GetTick() - time > 100)														// wystapienie timeoutu = 100 ms
			break;

	time = HAL_GetTick();
	while(time + 1000 > HAL_GetTick())														// wystapienie timeoutu = 1 s
	{
		length = wait_for_msg();
		if(length)
		{
			if(!ans_len)																	// jesli odpowiedz jeszcze nie przyszla
			{
				ans_len = check_CWJAP(UART_Rx_msg, out);									// sprawdzenie odpowiedzi
			}
			switch(check_cmd_status(UART_Rx_msg))											// sprawdzenie statusu wykonania komendy
			{
			case cmd_ok:																	// komenda zakonczona powodzeniem
				return ans_len;																// zwraca dlugosc odpowiedzi
			case cmd_error:																	// komenda zakonczona bledem
				return 0;
			default:
				ESP_update_status(UART_Rx_msg, length);										// aktualizacja statusu polaczenia
			}
		}
	}

	return 0;
}


uint8_t ESP_at_cipstamac_ask(UART_HandleTypeDef *huart, uint8_t *out)						// wyslanie zapytania CIPSTAMAC - pobranie adresu MAC modulu WiFi
{
	uint8_t length;
	uint8_t ans_len = 0;																	// dlugosc odpowiedzi
	uint32_t time;

	length = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPSTAMAC?\r\n");

	tx_flag = 0;
	time = HAL_GetTick();
	HAL_UART_Transmit_IT(huart, UART_Tx_at_buf, length);									// wyslanie komendy zapytania
	while(!tx_flag)																			// oczekiwanie na wyslanie
		if(HAL_GetTick() - time > 100)														// wystapienie timeoutu = 100 ms
			break;

	time = HAL_GetTick();
	while(time + 1000 > HAL_GetTick())														// wystapienie timeoutu = 1 s
	{
		length = wait_for_msg();
		if(length)
		{
			if(!ans_len)																	// jesli odpowiedz jeszcze nie przyszla
			{
				ans_len = check_CIPSTAMAC(UART_Rx_msg, out);								// sprawdzenie odpowiedzi
			}
			switch(check_cmd_status(UART_Rx_msg))											// sprawdzenie statusu wykonania komendy
			{
			case cmd_ok:																	// komenda zakonczona powodzeniem
				return ans_len;																// zwraca dlugosc odpowiedzi
			case cmd_error:																	// komenda zakonczona bledem
				return 0;
			default:
				ESP_update_status(UART_Rx_msg, length);										// aktualizacja statusu polaczenia
			}
		}
	}

	return 0;
}


uint8_t ESP_at_cipsto(UART_HandleTypeDef *huart, uint16_t timeout)							// wyslanie komendy CIPSTO - ustawienie timeoutu servera TCP
{
	uint8_t len;

	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPSTO=%d\r\n", (int)timeout);

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


uint8_t ESP_at_cipserver(UART_HandleTypeDef *huart, uint16_t port)							// wyslanie komendy CIPSERVER - otwarcie portu servera TCP
{
	uint8_t ret;
	uint8_t len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPSERVER=1,%d\r\n", (int)port);

	ret = ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);								// wyslanie komendy i czekanie na odpowiedz modulu WiFi

	if(ret == 1)																			// wykonanie komendy zakonczone powodzeniem
		ESP_connected_status |= ESP_CONN_STAT_TCP_OPEN;										// ustawienie statusu polaczenia

	return ret;
}


uint8_t ESP_at_cipstart(UART_HandleTypeDef *huart, uint16_t port)							// wyslanie komendy CIPSTART - otwarcie portu UDP
{
	uint8_t len;

	ESP_broadcast_id = (ESP_tcp_id == 0 ? 1 : 0);											// wyznaczenie id dla polaczenia UDP
	len = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPSTART=%d,\"UDP\",\"224.0.0.1\",%d\r\n", (int)ESP_broadcast_id, (int)port);

	return ESP_at_command_set(huart, UART_Tx_at_buf, len, 1000);							// wyslanie komendy i czekanie na odpowiedz modulu WiFi
}


void ESP_off()																				// wylaczenie modulu WiFi
{
#ifdef ESP_RESET_AT_VCC
	HAL_GPIO_WritePin(ESP_ON, 1);
#else
	HAL_GPIO_WritePin(ESP_RST, 0);															// wywolanie resetu modulu WiFi
#endif
	ESP_connected_status = ESP_CONN_STAT_WIFI_DISCONN;										// ustawienie statusu polaczenia
	change_led();																			// zmiana LED na czerwony
}

void ESP_reset(UART_HandleTypeDef *huart)													// reset modulu WiFi
{
	uint8_t length;

#ifdef ESP_RESET_AT_VCC
	HAL_GPIO_WritePin(ESP_ON, 1);
#else
	HAL_GPIO_WritePin(ESP_RST, 0);															// wywolanie resetu modulu WiFi
#endif
	ESP_connected_status = ESP_CONN_STAT_WIFI_DISCONN;										// ustawienie statusu polaczenia
	change_led();																			// zmiana LED na czerwony
	CYCL_BUF_clear();																		// wyczyszczenie bufora cyklicznego
	HAL_Delay(100);																			// czas potrzebny na reset modulu WiFi
	__HAL_UART_ENABLE_IT(huart, UART_IT_RXNE);												// wlaczenie przerwania od odbioru danych z modulu WiFi
#ifdef ESP_RESET_AT_VCC
	HAL_GPIO_WritePin(ESP_ON, 0);
#else
	HAL_GPIO_WritePin(ESP_RST, 1);															// koniec resetu modulu WiFi
#endif

	while(1)																				// oczekiwanie na wiadomosc "ready"
	{
		length = wait_for_msg();
		if(length)
		{
			if(check_ready(UART_Rx_msg))
				break;
			ESP_update_status(UART_Rx_msg, length);
		}
	}

	while(!ESP_at_echo_off(huart))															// wylaczenie echa z modulu WiFi
		HAL_Delay(50);
	while(!ESP_at_cipmux(huart))															// wlaczenie tryby multiple connections
		HAL_Delay(50);
}


uint8_t ESP_send(UART_HandleTypeDef *huart, uint8_t *buf, uint8_t id, uint16_t size)		// wyslanie ramki WiFi
{
	uint32_t time;																			// czas do pomiaru wystapienia timeoutu
	uint8_t length;
	uint8_t socket_flag;																	// flaga polaczenia odpowiedniego gniazda
	uint8_t send_ok_ret = 0;

	socket_flag = (id == ESP_tcp_id ? ESP_CONN_STAT_TCP_CONN : ESP_CONN_STAT_BROAD_OPEN);
	WatchdogReset();
	ESP_send_frames_counter++;																// inkrementacja licznika ramek

	length = (uint8_t)sprintf((char*)UART_Tx_at_buf, "AT+CIPSEND=%d,%d\r\n", (int)id, (int)size);
	tx_flag = 0;
	time = HAL_GetTick();
	HAL_UART_Transmit_IT(huart, UART_Tx_at_buf, length);									// wyslanie komendy wyslania ramki
	while(!tx_flag)																			// oczekiwanie na wyslanie
		if(HAL_GetTick() - time > 100)														// wystapienie timeoutu = 100 ms
			break;

	time = HAL_GetTick();
	WatchdogReset();
	while(time + 1000 > HAL_GetTick())														// wystapienie timeoutu = 1 s
	{
		length = wait_for_msg();
		if(length)																			// odebranie ramki z modulu WiFi
		{
			switch(check_cmd_status(UART_Rx_msg))
			{
			case cmd_ok:																	// wyslanie komendy zakonczone powodzeniem
			{
				tx_flag = 0;
				time = HAL_GetTick();
				HAL_UART_Transmit_IT(huart, buf, size);										// wyslanie tresci wiadomosci
				while(!tx_flag)																// oczekiwanie na wyslanie
					if(HAL_GetTick() - time > 100)											// wystapienie timeoutu = 100 ms
						break;

				time = HAL_GetTick();
				while(ESP_connected_status & socket_flag)									// petla trwa poki gniazdo nie zostanie rozlaczone
				{
					length = wait_for_msg();
					if(length)																// odebranie ramki z modulu WiFi
					{
						send_ok_ret = check_SEND_OK(UART_Rx_msg);							// sprawdzenie potwierdzenia wyslania wiadomosci
						if(send_ok_ret)
						{
							send_ack_time(time);											// wyslanie dlugiego czasu oczekiwania na ACK

							return send_ok_ret;												// wyslanie zakonczone powodzeniem
						}
						switch(check_cmd_status(UART_Rx_msg))								// odebranie innej ramki w czasie oczekiwania na potwierdzenie wyslania wiadomosci
						{
						case cmd_ok:														// w tym momenciemodul WiFi nie powinien wyslac ramki "ok" - blad
						case cmd_error:														// wystapienie bledu
							return 0;														// wyslanie zakonczone niepowodzeniem
						default:
							ESP_update_status(UART_Rx_msg, length);							// aktualizacja statusu polaczenia
						}
					}
				}
				send_ack_time(time);														// wyslanie dlugiego czasu oczekiwania na ACK

				return 0;
			}
			case cmd_error:																	// wyslanie komendy zakonczone niepowodzeniem
			{
				return 0;
			}
			default:																		// odebranie innej ramki w czasie oczekiwania na potwierdzenie odebrania komendy
				ESP_update_status(UART_Rx_msg, length);										// aktualizacja statusu polaczenia
			}
		}
	}
	return 0;
}


uint8_t ESP_send_udp(UART_HandleTypeDef *huart, uint8_t *buf, uint8_t size)					// wyslanie broadcasta
{
	return ESP_send(huart, buf, ESP_broadcast_id, size);
}


uint8_t ESP_send_tcp(UART_HandleTypeDef *huart, uint8_t *buf, uint16_t size)				// wyslanie ramki TCP
{
	return ESP_send(huart, buf, ESP_tcp_id, size);
}


void ESP_UART_RxCallback(uint8_t x)															// zapisanie odebranego znaku w buforze cyklicznym
{
	CYCL_BUF_set_data(x);
}
