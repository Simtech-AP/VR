/*
 * modes.c
 *
 *  Created on: 05.05.2020
 */

#include "stm32f1xx_hal.h"
#include "main.h"
#include <stdio.h>
#include <stdlib.h>
#include "usbd_cdc_if.h"
#include "esp_comm.h"
#include "modes.h"
#include "pendant_defs.h"


extern UART_HandleTypeDef *huart_esp;

uint8_t UART_Tx_button[3];													// bufor nadawczy dla deadmanow i e-stopu
uint8_t UART_Tx_broadcast[3];												// bufor nadawczy dla broadcastu
uint8_t UART_Tx_battery[4];													// bufor nadawczy dla stanu naladowania baterii
uint8_t UART_Tx_dbg_battery[6];												// bufor nadawczy dla napiecia na akumulatorach
uint8_t UART_Tx_dbg_string[50];												// bufor nadawczy dla nazwy sieci i adresu MAC
uint8_t UART_Tx_dbg_rssi[3];												// bufor nadawczy dla sily sygnalu
uint8_t UART_Tx_dbg_frame_counter[6];										// bufor nadawczy dla licznika ramek
uint8_t COM_Tx_buf[100];													// bufor nadawczy dla komunikacji USB w trybie DBG
uint8_t COM_Tx_buf_len;														// dlugosc ramki USB w trybie DBG


uint8_t crc(uint8_t *buf, uint8_t len)										// obliczanie sumy kontrolnej
{
	uint8_t x = 0;
	uint8_t i;

	for(i = 0; i < len; i++)
		x ^= buf[i];

	return x;
}

void PendantModes_init(uint8_t *ip)											// inicjalizacja buforow nadawczych
{
	UART_Tx_broadcast[0] = FRAME_TYPE_BROADCAST;
	UART_Tx_broadcast[1] = ip[3];
	UART_Tx_broadcast[2] = crc(UART_Tx_broadcast, 2);
	UART_Tx_battery[0] = FRAME_TYPE_BATTERY;
	UART_Tx_dbg_battery[0] = PENDANT_DBG_ID_BAT_V;
	UART_Tx_dbg_battery[2] = '.';
	UART_Tx_dbg_rssi[0] = PENDANT_DBG_ID_RSSI;
	UART_Tx_dbg_frame_counter[0] = PENDANT_DBG_ID_FRM_CNT;
}

uint8_t PendantSend_broadcast(uint8_t mode)									// wysylanie broadcastu
{
	switch(mode)
	{
	case PENDANT_MODE_WIFI:
	case PENDANT_MODE_WIFIUSB:
	{
		return ESP_send_udp(huart_esp, UART_Tx_broadcast, 3);				// broadcast wysylany tylko przez WiFi
	}
	}

	return 0;
}


uint8_t PendantSend_button(uint8_t mode, uint8_t type, uint8_t number)		// wyslanie zmiany stanu deadmanow lub e-stopu
{
	UART_Tx_button[0] = type + 1;											// wcisniety / puszczony
	UART_Tx_button[1] = number;												// numer przycisku
	UART_Tx_button[2] = crc(UART_Tx_button, 2);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		if(UART_Tx_button[0] == FRAME_TYPE_BUTTON_DOWN)
			COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "PRESS   %02d\r\n", number);
		else
			COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "UNPRESS %02d\r\n", number);
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_button, 3);
	}
	case PENDANT_MODE_USB:
	{
		while(CDC_Transmit_FS(UART_Tx_button, 3));
		return 1;
	}
	}

	return 0;
}

uint8_t PendantSend_switch(uint8_t mode, uint8_t *data, uint16_t size)		// wyslanie stanu przyciskow
{
	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		for(uint16_t i = 0; i < size; i++)
		{
			switch(data[i * 3])
			{
			case FRAME_TYPE_BUTTON_DOWN:
				COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "PRESS   %02d\r\n", data[i * 3 + 1]);
				break;
			case FRAME_TYPE_BUTTON_UP:
				COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "UNPRESS %02d\r\n", data[i * 3 + 1]);
				break;
			default:
				return 0;
			}
			CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
		}
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, data, size * 3);
	}
	case PENDANT_MODE_USB:
	{
		while(CDC_Transmit_FS(data, size * 3));
		return 1;
	}
	}

	return 0;
}

uint8_t PendantSend_touch(uint8_t mode, uint8_t *data)						// wyslanie stanu touchpada
{
	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)(COM_Tx_buf), "TOUCH");
		for(uint8_t i = 1; i < 16; i++)
		{
			COM_Tx_buf_len += (uint8_t)sprintf((char*)(COM_Tx_buf + COM_Tx_buf_len), "\t%u", data[i]);
		}
		COM_Tx_buf_len += (uint8_t)sprintf((char*)(COM_Tx_buf + COM_Tx_buf_len), "\r\n");
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, data, 17);
	}
	case PENDANT_MODE_USB:
	{
		while(CDC_Transmit_FS(data, 17));
		return 1;
	}
	}

	return 0;
}

uint8_t PendantSend_battery(uint8_t mode, uint8_t val)						// wyslanie poziomu naladowania baterii
{
	UART_Tx_battery[1] = val;												// wartosc 0 - 100
	UART_Tx_battery[2] = crc(UART_Tx_battery, 2);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "POWER %d\r\n", (int)val);
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_battery, 3);
	}
	case PENDANT_MODE_USB:
	{
		while(CDC_Transmit_FS(UART_Tx_battery, 3));
		return 1;
	}
	}

	return 0;
}

uint8_t decode_cwlap(uint8_t type, uint8_t *buf, uint8_t len, uint8_t *out)	// wyodrebnienie nazwy sieci, sily sygnalu i adresu mac z odpowiedzi na CWLAP
{
	uint8_t commas[3], i, tmp = 0;

	for(i = 0; i < len; i++)												// zapisanie indeksow separatorow w odpowiedzi
	{
		if(buf[i] == ',')
		{
			commas[tmp] = i;
			tmp++;
			if(tmp == 3)
				break;
		}
	}

	switch(type)
	{
	case 0:																	// nazwa sieci
	{
		for(i = 0; i < commas[0]; i++)
			out[i] = buf[i];
		return commas[0];
	}
	case 1:																	// adres MAC
	{
		tmp = commas[1] - commas[0] - 1;
		for(i = 0; i < tmp; i++)
			out[i] = buf[i + commas[0] + 1];
		return tmp;
	}
	case 2:																	// sila sygnalu
	{
		return (uint8_t)abs(atoi((char*)(&buf[commas[2] + 1])));
	}
	}

	return 0;
}

uint8_t PendantSend_dbg_ssid(uint8_t mode, uint8_t *buf, uint8_t len)		// wyslanie nazwy sieci
{
	uint8_t out[50];
	uint8_t i;

	len = decode_cwlap(0, buf, len, out);
	out[len] = 0;

	UART_Tx_dbg_string[0] = PENDANT_DBG_ID_SSID;
	for(i = 1; i < len - 1; i++)
		UART_Tx_dbg_string[i] = out[i];
	UART_Tx_dbg_string[len - 1] = crc(UART_Tx_dbg_string, len - 1);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "ssid: %s\r\n", out);
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_dbg_string, len);
	}
	}

	return 0;
}

uint8_t PendantSend_dbg_rrsi(uint8_t mode, uint8_t *buf, uint8_t len)		// wyslanie sily sygnalu
{
	UART_Tx_dbg_rssi[1] = decode_cwlap(2, buf, len, 0);
	UART_Tx_dbg_rssi[2] = crc(UART_Tx_dbg_rssi, 2);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "rrsi: -%d\r\n", (int)(UART_Tx_dbg_rssi[1]));
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_dbg_rssi, 3);
	}
	}
	return 0;
}

uint8_t PendantSend_dbg_mac(uint8_t mode, uint8_t *buf, uint8_t len)		// wyslanie adresu MAC sieci
{
	uint8_t out[50];
	uint8_t i;

	len = decode_cwlap(1, buf, len, out);
	out[len] = 0;

	UART_Tx_dbg_string[0] = PENDANT_DBG_ID_MAC;
	for(i = 1; i < len - 1; i++)
		UART_Tx_dbg_string[i] = out[i];
	UART_Tx_dbg_string[len - 1] = crc(UART_Tx_dbg_string, len - 1);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "mac : %s\r\n", out);
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_dbg_string, len);
	}
	}
	return 0;
}

uint8_t PendantSend_dbg_bat(uint8_t mode, uint16_t bat)						// wyslanie napiecia na akumulatorach
{
	uint8_t tmp = (uint8_t)(bat % 10);										// bat = 100 * <napiecie na akumulatorach>

	UART_Tx_dbg_battery[4] = tmp + '0';										// drugie miejsce po przecinku
	bat = bat - (uint16_t)tmp;
	bat = bat / 10;
	tmp = (uint8_t)(bat % 10);
	UART_Tx_dbg_battery[3] = tmp + '0';										// pierwsze miejsce po przecinku
	bat = bat - (uint16_t)tmp;
	tmp = (uint8_t)(bat / 10);
	UART_Tx_dbg_battery[1] = tmp + '0';										// liczba jednosci
	UART_Tx_dbg_battery[5] = crc(UART_Tx_dbg_battery, 5);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "bat:  %c.%c%c\r\n", (char)(UART_Tx_dbg_battery[1]), (char)(UART_Tx_dbg_battery[3]), (char)(UART_Tx_dbg_battery[4]));
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_dbg_battery, 6);
	}
	}
	return 0;
}

uint8_t PendantSend_dbg_cnt(uint8_t mode, uint32_t cnt)						// wyslanie licznika wyslanych ramek
{
	UART_Tx_dbg_frame_counter[1] = (uint8_t)cnt;							// wysylane w formacie little endian
	UART_Tx_dbg_frame_counter[2] = (uint8_t)(cnt >> 8);
	UART_Tx_dbg_frame_counter[3] = (uint8_t)(cnt >> 16);
	UART_Tx_dbg_frame_counter[4] = (uint8_t)(cnt >> 24);
	UART_Tx_dbg_frame_counter[5] = crc(UART_Tx_dbg_frame_counter, 5);

	switch(mode)
	{
	case PENDANT_MODE_WIFIUSB:
	{
		COM_Tx_buf_len = (uint8_t)sprintf((char*)COM_Tx_buf, "cnt:  %d\r\n", (int)cnt);
		CDC_Transmit_FS(COM_Tx_buf, COM_Tx_buf_len);
	}
	case PENDANT_MODE_WIFI:
	{
		return ESP_send_tcp(huart_esp, UART_Tx_dbg_frame_counter, 6);
	}
	}
	return 0;
}


