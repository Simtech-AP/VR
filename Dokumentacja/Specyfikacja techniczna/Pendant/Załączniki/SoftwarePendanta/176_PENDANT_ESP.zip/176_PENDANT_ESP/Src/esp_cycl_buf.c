/*
 * esp_cycl_buf.c
 *
 *  Created on: 11.10.2019
 */


#include "stm32f1xx_hal.h"
#include "esp_cycl_buf.h"


uint8_t cyclical_buffer[CYCLICAL_BUFFER_SIZE];										// bufor cykliczny
uint8_t cyclical_buffer_ptr_rd = 0;													// wskaznik do odczytu z bufora cyklicznego
uint8_t cyclical_buffer_ptr_wr = 0;													// wskaznik do zapisu w buforze cyklicznym
uint8_t cyclical_buffer_enter_index[CYCLICAL_BUFFER_MAX_MSG_COUNT];					// bufor cykliczny zawierajacy pozycje separatorow wiadomosci w buforze cyclical_buffer
uint8_t cyclical_buffer_enter_index_rd = 0;											// wskaznik do odczytu z bufora z separatorami
uint8_t cyclical_buffer_enter_index_wr = 0;											// wskaznik do zapisu w buforze z separatorami


uint8_t CYCL_BUF_get_data()															// pobranie znaku z bufora cyklicznego
{
	uint8_t data = cyclical_buffer[cyclical_buffer_ptr_rd];							// pobranie znaku z bufora

	cyclical_buffer_ptr_rd++;														// inkrementacja wskaznika do odczytu
	if(cyclical_buffer_ptr_rd == CYCLICAL_BUFFER_SIZE)
		cyclical_buffer_ptr_rd = 0;

	// pobrano cala wiadomosc (kolejny znak jest separatorem)
	if(cyclical_buffer_ptr_rd == cyclical_buffer_enter_index[cyclical_buffer_enter_index_rd])
	{
		cyclical_buffer_enter_index_rd++;											// inkrementacja wskaznika do odczytu z bufora z separatorami
		if(cyclical_buffer_enter_index_rd == CYCLICAL_BUFFER_MAX_MSG_COUNT)
			cyclical_buffer_enter_index_rd = 0;
	}

	return data;
}


void CYCL_BUF_set_data(uint8_t data)												// dodanie znaku do bufora cyklicznego
{
	cyclical_buffer[cyclical_buffer_ptr_wr] = data;									// zapisanie znaku w buforze

	cyclical_buffer_ptr_wr++;														// inkrementacja wskaznika do zapisu
	if(cyclical_buffer_ptr_wr == CYCLICAL_BUFFER_SIZE)
		cyclical_buffer_ptr_wr = 0;

	if(data == '\n')																// odebrano separator
	{
		// zapisanie indeksu separatora
		cyclical_buffer_enter_index[cyclical_buffer_enter_index_wr] = cyclical_buffer_ptr_wr;

		cyclical_buffer_enter_index_wr++;											// inkrementacja wskaznika do zapisu w buforze z separatorami
		if(cyclical_buffer_enter_index_wr == CYCLICAL_BUFFER_MAX_MSG_COUNT)
			cyclical_buffer_enter_index_wr = 0;
	}

	if(cyclical_buffer_ptr_wr == cyclical_buffer_ptr_rd)							// przepelnienie bufora cyklicznego
	{
		cyclical_buffer_ptr_rd++;													// inkrementacja wskaznika do odczytu - usuniecie najstarszego znaku
		if(cyclical_buffer_ptr_rd == CYCLICAL_BUFFER_SIZE)
			cyclical_buffer_ptr_rd = 0;
	}
}


uint8_t CYCL_BUF_check_new_frame_flag()												// sprawdzenie flagi odebrania nowej wiadomosci
{
	// ilosc wiadomosci w buforze jest rowna roznicy miedzy wskaznikiem do zapisu a wskaznikiem do odczytu z bufora z separatorami
	if(cyclical_buffer_enter_index_wr == cyclical_buffer_enter_index_rd)			// w buforze nie ma nieodczytanej wiadomosci zakonczonej separatorem
		return 0;

	if(cyclical_buffer_enter_index_wr > cyclical_buffer_enter_index_rd)				// wskaznik do zapisu jest za wskaznikiem do odczytu
		return cyclical_buffer_enter_index_wr - cyclical_buffer_enter_index_rd;

	// wskaznik do zapisu doszedl do konca bufora i przeszedl na jego poczatek
	return CYCLICAL_BUFFER_MAX_MSG_COUNT + cyclical_buffer_enter_index_wr - cyclical_buffer_enter_index_rd;
}


uint8_t CYCL_BUF_check_frame_length()												// pobranie dlugosci nowej wiadomosci
{
	uint8_t len;

	if(cyclical_buffer_enter_index[cyclical_buffer_enter_index_rd] >= cyclical_buffer_ptr_rd)
		// indeks separatora odczytywanej wiadomosci jest za wskaznikiem do odczytu
		len = cyclical_buffer_enter_index[cyclical_buffer_enter_index_rd] - cyclical_buffer_ptr_rd;
	else
		// indeks separatora odczytywanej wiadomosci doszedl do konca bufora i przeszedl na jego poczatek
		len = CYCLICAL_BUFFER_SIZE + cyclical_buffer_enter_index[cyclical_buffer_enter_index_rd] - cyclical_buffer_ptr_rd;

	return len;
}


void CYCL_BUF_clear()																// wyczyszczzenie bufora cyklicznego
{
	cyclical_buffer_ptr_rd = 0;
	cyclical_buffer_ptr_wr = 0;
	cyclical_buffer_enter_index_rd = 0;
	cyclical_buffer_enter_index_wr = 0;
}
