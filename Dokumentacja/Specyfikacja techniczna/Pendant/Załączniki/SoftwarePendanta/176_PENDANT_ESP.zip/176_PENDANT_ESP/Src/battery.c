/*
 * battery.c
 *
 *  Created on: 05.05.2020
 */

#include "stm32f1xx_hal.h"
#include "main.h"
#include "battery.h"


uint32_t battery_sum = 0;													// suma do liczenia sredniej z danego okresu
uint16_t battery_count = 0;													// ilosc probek w sumie do liczenia sredniej z danego okresu
uint32_t battery_averages[BATTERY_AVERAGES_LEN];							// tablica wartosci srednich odczytow z ADC na akumulatorach w kolejnych okresach
uint8_t battery_averages_index = 0;											// indeks w tablicy battery_averages
uint8_t battery_first_avg_flag = 0;											// flaga pierwszego zapelnienia tablicy srednich
uint32_t battery_send_adc = 0xffffffff;										// wartosc ADC na akumulatorach, z ktorej jest liczona wartosc wysylana
uint16_t battery_voltage = 0;												// wartosc napiecia na akumulatorach
volatile uint8_t usb_v = 0;													// stan podlaczenia USB
uint16_t adcBuffer[2];														// bufor do odczytu z ADC
uint32_t battery_time = 0;													// czas ostatniej aktualizacji wartosci napiecia na akumulatorach
uint8_t low_battery_cnt = 0;												// licznik probek ze zbyt niskim poziomem naladowania akumulatorow
uint32_t tracker_time = 0;													// czas odebrania ostatniego polecenia ladowania trackera
uint8_t tracker_is_chrg = 0;												// flaga ladowania sie trackera
volatile chrg_led_state_type chrg_led_current_state = init;					// aktualny stan led
extern TIM_HandleTypeDef *htim_chrg_led;									// timer do migania - miga wyjsciem wlaczajacym kolor zielony
uint16_t battery_voltage_ref[20] = {820, 810, 800, 790, 780,				// tablica przeksztalcajaca napiecie na procent naladowania akumulatorow
									770, 760, 750, 740, 730,
									720, 710, 700, 690, 680,
									670, 660, 650, 640, 630};


void CHRG_LED_set_pwm(chrg_led_state_type state)							// zmiana stanu led
{
	chrg_led_state_type old = chrg_led_current_state;						// zapisanie dotychczasowego stanu
	chrg_led_current_state = state;											// aktualizacja stanu

	switch(state)
	{
	case pendant_on:														// swieci na zielono
	{
		if(old != battery_charging)											// jesli timer do migania jest wlaczony
			HAL_TIM_Base_Stop_IT(htim_chrg_led);							// nalezy go wylaczyc
		HAL_GPIO_WritePin(EXT1_RED, 0);
		HAL_GPIO_WritePin(EXT2_GREEN, 1);
		break;
	}
	case battery_charging:													// swieci na czerwono
	{
		if(old != pendant_on)												// jesli timer do migania jest wlaczony
			HAL_TIM_Base_Stop_IT(htim_chrg_led);							// nalezy go wylaczyc
		HAL_GPIO_WritePin(EXT1_RED, 1);
		HAL_GPIO_WritePin(EXT2_GREEN, 0);
		break;
	}
	case battery_charged:													// miga na zielono
	{
		if(old != low_battery)												// jesli timer do migania jest wylaczony
			HAL_TIM_Base_Start_IT(htim_chrg_led);							// nalezy go wlaczyc
		HAL_GPIO_WritePin(EXT1_RED, 0);
		break;
	}
	case low_battery:														// miga na czerwono
	{
		if(old != battery_charged)											// jesli timer do migania jest wylaczony
			HAL_TIM_Base_Start_IT(htim_chrg_led);							// nalezy go wlaczyc
		HAL_GPIO_WritePin(EXT1_RED, 1);
		break;
	}
	case pendant_off:														// nie swieci
	{
		if((old == low_battery) || (old == battery_charged))				// jesli timer do migania jest wlaczony
			HAL_TIM_Base_Stop_IT(htim_chrg_led);							// nalezy go wylaczyc
		HAL_GPIO_WritePin(EXT1_RED, 0);
		HAL_GPIO_WritePin(EXT2_GREEN, 0);
		break;
	}
	default:
		break;
	}
}


void CHRG_LED_change(chrg_led_state_type state)								// aktualizacja stanu led
{
	if(state == chrg_led_current_state)										// stan led sie nie zmienil
		return;

	CHRG_LED_set_pwm(state);												// zmiana stanu led
}


void CHRG_LED_check(uint8_t on)												// sprawdzenie stanu akumulatora i aktualizacja stanu led
{
	if(on)																	// pendant wlaczony na przycisku
	{
		if(usb_v)															// USB podlaczone - sprawdzone przez ADC
		{
			if(HAL_GPIO_ReadPin(CHRG_STATE) == GPIO_PIN_RESET)				// ladowarka laduje
				CHRG_LED_change(battery_charging);
			else															// ladowarka nie laduje
				CHRG_LED_change(pendant_on);
		}
		else																// USB niepodlaczone - sprawdzone przez ADC
		{
			if(BATTERY_get_percentage() <= 5)								// niskie napiecie
				CHRG_LED_change(low_battery);
			else
				CHRG_LED_change(pendant_on);
		}
	}
	else																	// pendan wylaczony na przycisku, podlaczone USB
	{
		if(HAL_GPIO_ReadPin(CHRG_STATE) == GPIO_PIN_RESET)					// ladowarka laduje
			CHRG_LED_change(battery_charging);
		else																// ladowarka nie laduje
			CHRG_LED_change(battery_charged);
	}
}


void BATTERY_turn_off()														// wylaczenie pendanta na przycisku
{
	HAL_GPIO_WritePin(UC_ON, 0);											// wylaczenie procesora po puszczeniu przycisku

	if(usb_v)																// jesli USB jest podlaczone:
		HAL_NVIC_SystemReset();												// reset programowy - koniec wykonania funkcji

	CHRG_LED_change(pendant_off);											// jesli USB nie jest podlaczone: zgaszenie diody
	while(1);																// oczekiwanie na puszczenie przycisku, wylaczenie procesora
}


void BATTERY_count_battery_level()											// obliczenie napiecia na akumulatorach
{
	uint8_t i;
	uint32_t min_val = battery_averages[0], max_val = battery_averages[0];

	for(i = 1; i < BATTERY_AVERAGES_LEN; i++)								// znalezienie minimum i maksimum wartosci z tablicy srednich
	{
		if(battery_averages[i] >  max_val)
			max_val = battery_averages[i];
		if(battery_averages[i] <  min_val)
			min_val = battery_averages[i];
	}

	if(min_val > battery_send_adc)											// aktualizacja wartosci wysylanej
		battery_send_adc = min_val;											// jesli minimum aktualnej tablicy srednich
	else if(max_val < battery_send_adc)										// jest mniejsze od aktualnej wartosci wysylanej
		battery_send_adc = max_val;											// lub maksimum jest wieksze

	battery_voltage = (uint16_t)((float)battery_send_adc * 0.2116 + 0.611);	// przeksztalcenie wartosci z ADC na wartosc napiecia * 100

	if(battery_voltage < battery_voltage_ref[19])							// jesli wysylana wartosc napiecia jest mniejsza niz wartosc napiecia dla 0 %
		BATTERY_turn_off();													// wylaczenie pendanta
}


uint16_t BATTERY_get_voltage()												// pobranie wartosci napiecia na akumulatorach
{
	return battery_voltage;
}


uint16_t BATTERY_get_percentage()											// pobranie procentu naladowania akumulatorow
{
	BATTERY_check_battery_level();
	for(uint8_t i = 0; i < 20; i++)
		if(battery_voltage > battery_voltage_ref[i])
			return 100 - i * 5;

	return 0;
}


void BATTERY_check_battery_level()											// aktualizacja wartosci napiecia na akumulatorach
{
	if(!battery_first_avg_flag)												// przed pierwszym zapelnieniem tablicy srednich nie robi nic
		return;

	if(battery_voltage)
		if(HAL_GetTick() - battery_time < BATTERY_COUNT_PERIOD)				// wartosc napiecia jest aktualizowana nie czesciej niz co BATTERY_COUNT_PERIOD ms
			return;

	battery_time = HAL_GetTick();											// zapisanie czasu aktualizacji wartosci napiecia na akumulatorach
	BATTERY_count_battery_level();											// aktualizacja wartosci napiecia na akumulatorach
}


void TRACKER_chrg_on()														// wlaczenie ladowania trackera
{
	tracker_time = HAL_GetTick();
	if(!tracker_is_chrg)
	{
		HAL_GPIO_WritePin(TRACKER_EN, 1);
		tracker_is_chrg = 1;
	}
}


void TRACKER_chrg_off()														// wylaczenie ladowania trackera
{
	if(tracker_is_chrg)
	{
		HAL_GPIO_WritePin(TRACKER_EN, 0);
		tracker_is_chrg = 0;
	}
}


void TRACKER_check_timeout()												// sprawdzenie timeoutu ladowania trackera
{
	if(tracker_is_chrg)
	{
		if(HAL_GetTick() - tracker_time > 5000)
		{
			HAL_GPIO_WritePin(TRACKER_EN, 0);
			tracker_is_chrg = 0;
		}
	}
}


void ADC_init(ADC_HandleTypeDef *hadc, DMA_HandleTypeDef *hdma_adc)			// inicjalizacja ADC
{
	HAL_ADC_Start_DMA(hadc, (uint32_t*)adcBuffer, 2);
}


void ADC_BatteryCallback(uint8_t source)									// przetwarzanie wartosci z ADC, wywolywane w przerwaniu z DMA
{
	uint32_t battery_tmp = 0;

	if(!battery_first_avg_flag)												// przed pierwszym zapelnieniem tablicy srednich
	{
		if(source != BATTERY_ADC_CALLBACK_SOURCE_DMA)						// czestotliwosc probkowania nadaje przerwanie DMA
			return;
	}
	else																	// po pierwszym zapelnieniu tablicy srednich
	{
		if(source != BATTERY_ADC_CALLBACK_SOURCE_TIM)						// czestotliwosc probkowania nadaje przerwanie TIM
			return;
	}

	usb_v = ((adcBuffer[1] < 2000) ? 0 : 1);								// aktualizacja stanu podlaczenie USB

	battery_tmp = adcBuffer[0];												// pobranie wartosci ADC na akumulatorach
	if(battery_tmp < BATTERY_OFF_ADC_LEVEL)									// odczyt ADC z akumulatorow jest mniejszy niz prog wylaczenia
	{
		low_battery_cnt++;
		if(low_battery_cnt == 10)											// po 10 zbyt niskich odczytach po rzad
			BATTERY_turn_off();												// pendant jest wylaczany
	}
	else																	// odpowiedni odczyt resetuje licznik
		low_battery_cnt = 0;

	battery_sum += battery_tmp;												// aktualizacja sumy do liczenia sredniej
	battery_count++;														// inkrementacja ilosci zebranych probek
	if(battery_count == BATTERY_SAMPLES_IN_AVG)								// zebrano zadana ilosc probek do policzenia sredniej
	{
		battery_count = 0;													// zerowanie ilosci zebranych probek
		// obliczenie srendniej z danego okresu
		battery_averages[battery_averages_index] = battery_sum / BATTERY_SAMPLES_IN_AVG;
		battery_sum = 0;													// zerowanie sumy do liczenia sredniej
		battery_averages_index++;											// inkrementacja indeksu w tablicy srednich
		if(battery_averages_index == BATTERY_AVERAGES_LEN)
		{
			battery_averages_index = 0;
			if(!battery_first_avg_flag)										// pierwszy raz zapelniono cala tablice
			{
				battery_send_adc = 0;
				for(uint8_t i = 0; i < BATTERY_AVERAGES_LEN; i++)
					battery_send_adc += battery_averages[i];				// obliczenie pierwszej wartosci do wyslania jako sredniej ze srednich
				battery_send_adc = battery_send_adc / BATTERY_AVERAGES_LEN;
				battery_first_avg_flag = 1;									// ustawienie flagi pierwszego zapelnienia tablicy srednich
			}
		}
	}
}
