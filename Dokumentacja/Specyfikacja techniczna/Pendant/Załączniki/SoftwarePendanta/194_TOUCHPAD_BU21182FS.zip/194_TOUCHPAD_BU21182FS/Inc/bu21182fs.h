/*
 * bu21182fs.h
 *
 *  Created on: 09.05.2020
 */

#ifndef BU21182FS_H_
#define BU21182FS_H_

// adresy slave'ow I2C
#define BU21182FS_ADDR_L					0x5C
#define BU21182FS_ADDR_H					0x5D

// adresy rejestrow ukladu BU21182FS
#define BU21182FS_REG_DATA_CS				0x00
#define BU21182FS_REG_FDATA_CS				0x15
#define BU21182FS_REG_INT_FACT				0x40
#define BU21182FS_REG_SW_ON_DET				0x43
#define BU21182FS_REG_SW_OFF_DET			0x46
#define BU21182FS_REG_HOLD_DET				0x49
#define BU21182FS_REG_HOLD_RPT_DET			0x4C
#define BU21182FS_REG_MULT_ON_DET			0x4F
#define BU21182FS_REG_MULT_OFF_DET			0x50
#define BU21182FS_REG_SW_STATE				0x54
#define BU21182FS_REG_VERSION				0x5F
#define BU21182FS_REG_GPIO					0x60
#define BU21182FS_REG_SENSITIVITY			0x66
#define BU21182FS_REG_THRESHOLDS			0x70
#define BU21182FS_REG_GAIN					0x98
#define BU21182FS_REG_FREQUENCY				0x99
#define BU21182FS_REG_CLR_INT_FACT			0xE0
#define BU21182FS_REG_CLR_SW_ON_DET			0xE2
#define BU21182FS_REG_CLR_SW_OFF_DET		0xE5
#define BU21182FS_REG_CLR_HOLD_DET			0xE8
#define BU21182FS_REG_CLR_HOLD_RPT_DET		0xEB
#define BU21182FS_REG_CLR_MULT_ON_DET		0xEE
#define BU21182FS_REG_CLR_MULT_OFF_DET		0xEF
#define BU21182FS_REG_RESET					0xF3
#define BU21182FS_REG_AVDD					0xFE
#define BU21182FS_REG_SENS_CMD				0xFF

// przerwania ukladu BU21182FS
#define BU21182FS_INT_FININI				0x01
#define BU21182FS_INT_FINCAL				0x04
#define BU21182FS_INT_FALCAL				0x08
#define BU21182FS_INT_INK					0x40
#define BU21182FS_INT_NOISE					0x80
#define BU21182FS_INT_SW_ON					0x01
#define BU21182FS_INT_SW_OFF				0x02
#define BU21182FS_INT_HLD					0x04
#define BU21182FS_INT_HLDRPT				0x08
#define BU21182FS_INT_MULT_ON				0x10
#define BU21182FS_INT_MULT_OFF				0x20
#define BU21182FS_INT_AVDDON				0x01
#define BU21182FS_INT_AVDDOFF				0x02

// czestotliwosci probkowania ukladu BU21182FS
#define BU21182FS_FREQ_1563					0x00
#define BU21182FS_FREQ_1024					0x10
#define BU21182FS_FREQ_781					0x20
#define BU21182FS_FREQ_391					0x30
#define BU21182FS_FREQ_298					0x40
#define BU21182FS_FREQ_195					0x50
#define BU21182FS_FREQ_156					0x60
#define BU21182FS_FREQ_130					0x70

// dane uzywane do resetu programowego ukladu BU21182FS
#define BU21182FS_RESET_DATA0				0x55
#define BU21182FS_RESET_DATA1				0xAA

#define FRAME_TYPE_TOUCH_STATE				10					// id ramki z wartosciami touchpadow
#define BU_COUNT							6					// ilosc ukladow BU21182FS
#define BU_SENSOR_COUNT						(BU_COUNT * 20)		// ilossc sensorow dotykowych
#define BU_PRESSED_COUNT					10					// ilosc wysylanych w jednej ramce sensorow dotykowych

typedef struct						// struktura parametrow ukladu BU21182FS
{
	I2C_HandleTypeDef *hi2c;		// interface I2C
	uint8_t address;				// adres slave'a I2C
	uint8_t number;					// numer ukladu BU21182FS
}BU21182FS_typedef;

typedef struct						// struktura przechowujaca konfiguracje sensorow dotykowych
{
	uint8_t *sensitivity;			// wskaznik na poczatek tablicy czulosci poszczegolnych sensorow
	uint8_t frequency;				// czestotliwosc probkowania
	uint8_t gain;					// wzmocnienie sensorow dotykowych
}BU21182FS_cfg_typedef;

typedef struct						// struktura okreslajaca aktywny sensor
{
	uint8_t lp;						// numer sensora
	uint8_t value;					// wartosc odczytu z sensora z zakresu 0 - 15
}BU21182FS_pressed_typedef;

void BU21182FS_Init(BU21182FS_cfg_typedef *cfg);			// konfiguracja ukladow BU21182FS
uint8_t BU21182FS_UartSend(UART_HandleTypeDef *huart);		// wysylanie ramki ze stanem touchpada
void BU21182FS_CheckStates();								// sprawdzenie odczytow z sensorow dotykowych
void BU21182FS_Reinit();									// wyzerowanie stanu touchpada przed ponownym wlaczenie pendanta

#endif /* BU21182FS_H_ */
