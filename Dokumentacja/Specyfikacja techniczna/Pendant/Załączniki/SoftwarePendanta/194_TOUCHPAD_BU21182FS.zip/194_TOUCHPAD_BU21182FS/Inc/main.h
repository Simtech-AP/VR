/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

// transmisja verbose, uzywana do testowania touchpada bez pendanta
//#define VERBOSE
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define KN_OUT0_Pin GPIO_PIN_13
#define KN_OUT0_GPIO_Port GPIOC
#define KN_OUT1_Pin GPIO_PIN_14
#define KN_OUT1_GPIO_Port GPIOC
#define KN_OUT2_Pin GPIO_PIN_15
#define KN_OUT2_GPIO_Port GPIOC
#define KL_IN1_Pin GPIO_PIN_0
#define KL_IN1_GPIO_Port GPIOC
#define KL_IN2_Pin GPIO_PIN_1
#define KL_IN2_GPIO_Port GPIOC
#define KL_IN3_Pin GPIO_PIN_2
#define KL_IN3_GPIO_Port GPIOC
#define KL_IN4_Pin GPIO_PIN_3
#define KL_IN4_GPIO_Port GPIOC
#define KA_IN0_Pin GPIO_PIN_6
#define KA_IN0_GPIO_Port GPIOA
#define KA_IN1_Pin GPIO_PIN_7
#define KA_IN1_GPIO_Port GPIOA
#define KL_OUT1_Pin GPIO_PIN_4
#define KL_OUT1_GPIO_Port GPIOC
#define KL_OUT2_Pin GPIO_PIN_5
#define KL_OUT2_GPIO_Port GPIOC
#define KA_IN7_Pin GPIO_PIN_0
#define KA_IN7_GPIO_Port GPIOB
#define KA_IN8_Pin GPIO_PIN_1
#define KA_IN8_GPIO_Port GPIOB
#define KA_IN2_Pin GPIO_PIN_12
#define KA_IN2_GPIO_Port GPIOB
#define KN_IN1_Pin GPIO_PIN_13
#define KN_IN1_GPIO_Port GPIOB
#define KL_OUT3_Pin GPIO_PIN_6
#define KL_OUT3_GPIO_Port GPIOC
#define KL_OUT4_Pin GPIO_PIN_7
#define KL_OUT4_GPIO_Port GPIOC
#define KN_IN0_Pin GPIO_PIN_8
#define KN_IN0_GPIO_Port GPIOC
#define KA_IN3_Pin GPIO_PIN_9
#define KA_IN3_GPIO_Port GPIOA
#define KA_IN4_Pin GPIO_PIN_10
#define KA_IN4_GPIO_Port GPIOA
#define KA_IN5_Pin GPIO_PIN_11
#define KA_IN5_GPIO_Port GPIOA
#define KA_IN6_Pin GPIO_PIN_12
#define KA_IN6_GPIO_Port GPIOA
#define KN_IN2_Pin GPIO_PIN_10
#define KN_IN2_GPIO_Port GPIOC
#define KN_IN3_Pin GPIO_PIN_11
#define KN_IN3_GPIO_Port GPIOC
#define KN_IN4_Pin GPIO_PIN_12
#define KN_IN4_GPIO_Port GPIOC
#define KN_IN5_Pin GPIO_PIN_2
#define KN_IN5_GPIO_Port GPIOD
#define BU_VCC_ON_Pin GPIO_PIN_4
#define BU_VCC_ON_GPIO_Port GPIOB
#define KA_IN9_Pin GPIO_PIN_5
#define KA_IN9_GPIO_Port GPIOB
#define KA_OUT0_Pin GPIO_PIN_6
#define KA_OUT0_GPIO_Port GPIOB
#define KA_OUT1_Pin GPIO_PIN_7
#define KA_OUT1_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
#define BU_VCC_ON BU_VCC_ON_GPIO_Port, BU_VCC_ON_Pin
#define KA_IN0 KA_IN0_GPIO_Port, KA_IN0_Pin
#define KA_IN1 KA_IN1_GPIO_Port, KA_IN1_Pin
#define KA_IN2 KA_IN2_GPIO_Port, KA_IN2_Pin
#define KA_IN3 KA_IN3_GPIO_Port, KA_IN3_Pin
#define KA_IN4 KA_IN4_GPIO_Port, KA_IN4_Pin
#define KA_IN5 KA_IN5_GPIO_Port, KA_IN5_Pin
#define KA_IN6 KA_IN6_GPIO_Port, KA_IN6_Pin
#define KA_IN7 KA_IN7_GPIO_Port, KA_IN7_Pin
#define KA_IN8 KA_IN8_GPIO_Port, KA_IN8_Pin
#define KA_IN9 KA_IN9_GPIO_Port, KA_IN9_Pin
#define KN_IN0 KN_IN0_GPIO_Port, KN_IN0_Pin
#define KN_IN1 KN_IN1_GPIO_Port, KN_IN1_Pin
#define KN_IN2 KN_IN2_GPIO_Port, KN_IN2_Pin
#define KN_IN3 KN_IN3_GPIO_Port, KN_IN3_Pin
#define KN_IN4 KN_IN4_GPIO_Port, KN_IN4_Pin
#define KN_IN5 KN_IN5_GPIO_Port, KN_IN5_Pin
#define KL_IN1 KL_IN1_GPIO_Port, KL_IN1_Pin
#define KL_IN2 KL_IN2_GPIO_Port, KL_IN2_Pin
#define KL_IN3 KL_IN3_GPIO_Port, KL_IN3_Pin
#define KL_IN4 KL_IN4_GPIO_Port, KL_IN4_Pin
#define KA_OUT0 KA_OUT0_GPIO_Port, KA_OUT0_Pin
#define KA_OUT1 KA_OUT1_GPIO_Port, KA_OUT1_Pin
#define KN_OUT0 KN_OUT0_GPIO_Port, KN_OUT0_Pin
#define KN_OUT1 KN_OUT1_GPIO_Port, KN_OUT1_Pin
#define KN_OUT2 KN_OUT2_GPIO_Port, KN_OUT2_Pin
#define KL_OUT1 KL_OUT1_GPIO_Port, KL_OUT1_Pin
#define KL_OUT2 KL_OUT2_GPIO_Port, KL_OUT2_Pin
#define KL_OUT3 KL_OUT3_GPIO_Port, KL_OUT3_Pin
#define KL_OUT4 KL_OUT4_GPIO_Port, KL_OUT4_Pin
#define BU_INT_Port GPIOA
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
