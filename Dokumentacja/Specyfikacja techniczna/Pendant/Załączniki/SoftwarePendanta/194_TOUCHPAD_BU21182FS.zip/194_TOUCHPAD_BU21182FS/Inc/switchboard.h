/*
 * switchboard.h
 *
 *  Created on: 15.05.2020
 */

#ifndef SWITCHBOARD_H_
#define SWITCHBOARD_H_

#define SB_CHANGED					1
#define SB_NOT_CHANGED				0
#define FRAME_TYPE_BUTTON_DOWN		1			// id ramki zawierajacej przycisniety przycisk
#define FRAME_TYPE_BUTTON_UP		2			// id ramki zawierajacej puszczony przycisk
#define SWITCH_NUMBER				53			// ilosc przyciskow

typedef enum
{
	not_changed = 0,
	pressed = 1,
	unpressed = 2
}SB_state;

struct SB_outPin;

typedef void (*SB_check)(struct SB_outPin *pin);

typedef struct SB_outPin		// struktura wspomagajaca proces odczytania stanu przyciskow podlaczonych do danego wyjscia K_y_OUTx
{
	uint16_t pin;				// numer pinu K_y_OUTx
	uint16_t old_state;			// poprzedni stan przyciskow (puszczony przycisk odpowiada ustawionemu bitowi)
	uint16_t new_state;			// obecny stan przyciskow (puszczony przycisk odpowiada ustawionemu bitowi)
	uint8_t size;				// ilosc przyciskow podlaczonych do wyjscia K_y_OUTx
	SB_state *state_tab;		// tablica zawierajaca stan przyciskow podlaczonych do danego wyjscia K_y_OUTx
	SB_check function;			// funkcja sluzaca do odczytania stanu podlaczonych przyciskow
}SB_outPin;


void SB_init();									// inicjalizacja struktury przyciskow
void SB_reinit();								// wyzerowanie stanow przyciskow
void SB_send(UART_HandleTypeDef *huart);		// wyslanie stanow zmienionych przyciskow
uint8_t SB_checkAll();							// sprawdzenie stanu przyciskow

#endif /* SWITCHBOARD_H_ */
