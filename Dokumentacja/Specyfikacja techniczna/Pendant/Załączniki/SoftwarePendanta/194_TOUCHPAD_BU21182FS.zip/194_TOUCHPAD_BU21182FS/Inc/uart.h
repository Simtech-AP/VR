/*
 * uart.h
 *
 *  Created on: 18.05.2020
 */

#ifndef UART_H_
#define UART_H_

#define UART_TX_FRAME_SIZE		18			// rozmiar ramki nadawczej

// inicjalizacja transmisji UART
void UART_init(UART_HandleTypeDef *huart, TIM_HandleTypeDef *htim);
uint8_t UART_getStart();		// odczytanie flagi komendy start
uint8_t UART_getStop();			// odczytanie flagi komendy stop


#endif /* UART_H_ */
