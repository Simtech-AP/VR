/*
 * bu21182fs.c
 *
 *  Created on: 09.05.2020
 */

#include "stm32f4xx_hal.h"
#include "main.h"
#ifdef VERBOSE
#include <stdio.h>
#endif
#include "bu21182fs.h"
#include "uart.h"

extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c2;
extern I2C_HandleTypeDef hi2c3;

BU21182FS_typedef bu_addr[BU_COUNT];								// adresacja poszczegolnych ukladow BU21182FS
uint8_t BU_send_touch[UART_TX_FRAME_SIZE];							// bufor nadawczy dla stanu touchpada
uint8_t BU_states[BU_SENSOR_COUNT];									// aktualne wartosci odczytow z sensorow dotykowych
BU21182FS_pressed_typedef BU_pressed[BU_PRESSED_COUNT];				// tablica wartosci sensorow do wyslania
BU21182FS_pressed_typedef BU_pressed_left[BU_PRESSED_COUNT];		// tablica wartosci sensorow z zakresu lewej reki
BU21182FS_pressed_typedef BU_pressed_right[BU_PRESSED_COUNT];		// tablica wartosci sensorow z zakresu prawej reki

// wpisanie wartosci do rejestrow ukladu BU21182FS
HAL_StatusTypeDef BU21182FS_Write(BU21182FS_typedef *bu, uint8_t reg, uint8_t *data, uint8_t length)
{
	uint8_t buf[length + 1];
	uint16_t addr = (uint16_t)(bu->address << 1);	// pole adresu z flaga Write = 0

	buf[0] = reg;									// adres pierwszego rejestru
	for(uint8_t i = 0; i < length; i++)				// wartosci rejestrow
		buf[i + 1] = data[i];

	// wyslanie adresu pierwszego odczytywanego rejestru i wartosci zapisywanych rejestrow
	return HAL_I2C_Master_Transmit(bu->hi2c, addr, buf, (uint16_t)(length + 1), 100);
}

// odczytanie wartosci z rejestrow ukladu BU21182FS
HAL_StatusTypeDef BU21182FS_Read(BU21182FS_typedef *bu, uint8_t reg, uint8_t *data, uint8_t length)
{
	uint16_t addr = (uint16_t)(bu->address << 1);			// pole adresu z flaga Write = 0

	HAL_I2C_Master_Transmit(bu->hi2c, addr, &reg, 1, 100);	// wyslanie adresu pierwszego odczytywanego rejestru
	addr |= 0x01;											// pole adresu z flaga Read = 1

	// odczytanie wartosci z rejestrow
	return HAL_I2C_Master_Receive(bu->hi2c, addr, data, length, 100);
}

// reset programowy ukladu BU21182FS
void BU21182FS_SoftwareReset(BU21182FS_typedef *bu)
{
	uint8_t data[2] = {BU21182FS_RESET_DATA0, BU21182FS_RESET_DATA1};

	BU21182FS_Write(bu, BU21182FS_REG_RESET, data, 2);
}

// sprawdzenie wersji firmware'u ukladu BU21182FS
uint8_t BU21182FS_FirmwareVersion(BU21182FS_typedef *bu)
{
	uint8_t data;

	BU21182FS_Read(bu, BU21182FS_REG_VERSION, &data, 1);

	return data;
}

// sprawdzenie przerwan ukladu BU21182FS
uint32_t BU21182FS_CheckInterrupt(BU21182FS_typedef *bu)
{
	uint8_t data_int[3];
	uint8_t zeros[3] = {0, 0, 0};

	if(BU21182FS_Read(bu, BU21182FS_REG_INT_FACT, data_int, 3) != HAL_OK)		// odczytanie flag przerwan
		return 0;																// blad w protokole I2C

	if((!data_int[0]) && (!data_int[1]) && (!data_int[2]))						// zadna flaga nie jest ustawiona
		return 0;

	// kasowanie ustawionych flag przerwn
	if(data_int[1] & BU21182FS_INT_SW_ON)
	{
		// switch on
		BU21182FS_Write(bu, BU21182FS_REG_CLR_SW_ON_DET, zeros, 3);
	}
	if(data_int[1] & BU21182FS_INT_SW_OFF)
	{
		// switch off
		BU21182FS_Write(bu, BU21182FS_REG_CLR_SW_OFF_DET, zeros, 3);
	}
	if(data_int[1] & BU21182FS_INT_HLD)
	{
		BU21182FS_Write(bu, BU21182FS_REG_CLR_HOLD_DET, zeros, 3);
	}
	if(data_int[1] & BU21182FS_INT_HLDRPT)
	{
		BU21182FS_Write(bu, BU21182FS_REG_CLR_HOLD_RPT_DET, zeros, 3);
	}
	if(data_int[1] & BU21182FS_INT_MULT_ON)
	{
		BU21182FS_Write(bu, BU21182FS_REG_CLR_MULT_OFF_DET, zeros, 1);
	}
	if(data_int[1] & BU21182FS_INT_MULT_OFF)
	{
		BU21182FS_Write(bu, BU21182FS_REG_CLR_MULT_OFF_DET, zeros, 1);
	}

	if((data_int[0]) || (data_int[2]))
		BU21182FS_Write(bu, BU21182FS_REG_CLR_INT_FACT, zeros, 2);

	// funkcja zwraca ustawione flagi przerwan jako uint32_t
	return (uint32_t)(data_int[0]) | ((uint32_t)(data_int[1]) << 8) | ((uint32_t)(data_int[2]) << 16);
}

// konfiguracja ukladow BU21182FS
void BU21182FS_Init(BU21182FS_cfg_typedef *cfg)
{
	uint8_t gpio_type[5] = {0, 0, 0, 0, 0};
	uint8_t sensitivity_tab[10];
	uint8_t sensor_cmd = 7;
	uint8_t avdd_on = 1;
	uint8_t gain = cfg->gain << 4;
	uint8_t i, j;
	uint32_t BU_initialized;

	bu_addr[0].hi2c = &hi2c1;
	bu_addr[1].hi2c = &hi2c1;
	bu_addr[2].hi2c = &hi2c2;
	bu_addr[3].hi2c = &hi2c2;
	bu_addr[4].hi2c = &hi2c3;
	bu_addr[5].hi2c = &hi2c3;
	bu_addr[0].address = BU21182FS_ADDR_L;
	bu_addr[1].address = BU21182FS_ADDR_H;
	bu_addr[2].address = BU21182FS_ADDR_L;
	bu_addr[3].address = BU21182FS_ADDR_H;
	bu_addr[4].address = BU21182FS_ADDR_L;
	bu_addr[5].address = BU21182FS_ADDR_H;
	for(i = 0; i < BU_COUNT; i++)
		bu_addr[i].number = i;

	BU_send_touch[0] = 255;
	BU_send_touch[1] = FRAME_TYPE_TOUCH_STATE;

	for(i = 0; i < BU_SENSOR_COUNT; i++)
		BU_states[i] = 0;

	for(i = 0; i < BU_COUNT; i++)
	{
		BU_initialized = 0;
		while((BU_initialized & 0x01) == 0)
		{
			BU_initialized = BU21182FS_CheckInterrupt(bu_addr + i);
		}

		for(j = 0; j < 10; j++)
		{
			sensitivity_tab[j] = (cfg->sensitivity[2 * j + i * 20] << 4) | cfg->sensitivity[2 * j + i * 20 + 1];
		}
		BU21182FS_Write(bu_addr + i, BU21182FS_REG_GPIO, gpio_type, 5);								// wszystkie io jako capacitive sensor
		BU21182FS_Write(bu_addr + i, BU21182FS_REG_SENSITIVITY, sensitivity_tab, 10);				// czulosc jednakowa
		BU21182FS_Write(bu_addr + i, BU21182FS_REG_GAIN, &gain, 1);									// wzmocnienie
		BU21182FS_Write(bu_addr + i, BU21182FS_REG_FREQUENCY, &(cfg->frequency), 1);				// czestotliwosc
		BU21182FS_Write(bu_addr + i, BU21182FS_REG_AVDD, &avdd_on, 1);								// avdd on
		BU21182FS_Write(bu_addr + i, BU21182FS_REG_SENS_CMD, &sensor_cmd, 1);						// kalibracja, detekcja
	}
}

// wysylanie ramki ze stanem touchpada
uint8_t BU21182FS_UartSend(UART_HandleTypeDef *huart)
{
	uint8_t i = 0;

#ifdef VERBOSE
	uint8_t data[120], len;

	len = (uint8_t)sprintf((char*)(data), "state:");
#else
	uint8_t crc = FRAME_TYPE_TOUCH_STATE;
#endif

#ifdef VERBOSE
	for(i = 0; i < BU_PRESSED_COUNT; i++)
	{
		len += (uint8_t)sprintf((char*)(data + len), "\t\t%3d  %x", BU_pressed[i].lp, BU_pressed[i].value);
	}
	len += (uint8_t)sprintf((char*)(data + len), "\r\n");
	HAL_UART_Transmit(huart, data, len, 100);
#else
	for(i = 0; i < BU_PRESSED_COUNT / 2; i++)
	{
		BU_send_touch[2 * i + 2] = BU_pressed[2 * i].lp;
		BU_send_touch[2 * i + 3] = BU_pressed[2 * i + 1].lp;
		BU_send_touch[i + 12] = (BU_pressed[2 * i].value << 4) | (BU_pressed[2 * i + 1].value);
		crc ^= BU_send_touch[2 * i + 2] ^ BU_send_touch[2 * i + 3] ^ BU_send_touch[i + 12];
	}
	BU_send_touch[17] = crc;
	HAL_UART_Transmit(huart, BU_send_touch, UART_TX_FRAME_SIZE, 100);
#endif

	return 0;
}

// odczytanie wartosci sensorow dotykowych z ukladu BU21182FS
uint8_t BU21182FS_GetValues(BU21182FS_typedef *bu, uint8_t *data)
{
	BU21182FS_Read(bu, BU21182FS_REG_DATA_CS, data, 20);

	return 0;
}

// sortowanie sensorow dotykowych lewej reki wg wartosci odczytow
uint8_t BU21182FS_SortLeft()
{
	uint8_t i, j, x;

	for(i = 0; i < BU_PRESSED_COUNT; i++)		// zerowanie tablicy
	{
		BU_pressed_left[i].lp = BU_SENSOR_COUNT;
		BU_pressed_left[i].value = 0;
	}

	for(i = 0; i < BU_PRESSED_COUNT; i++)		// znalezienie wartosci maksymalnej BU_PRESSED_COUNT razy
	{
		x = 40;
		for(j = 41; j < 100; j++)				// zakres sensorow: 40 - 55, 59 - 100
		{
			if(j == 56)
				j = 59;

			if(BU_states[j] > BU_states[x])
			{
				x = j;
			}
		}
		if(BU_states[x] < 76)					// odciecie szumow - uznanie wartosci jako 0
		{
			return i;							// zwraca ilosc niezerowych sensorow
		}
		BU_pressed_left[i].lp = x;				// zapisanie znalezionego maksimum
		BU_pressed_left[i].value = BU_states[x];
		BU_states[x] = 0;						// wyzerowanie znalezionego maksimum przed kolejna iteracja
	}

	return BU_PRESSED_COUNT;
}

// sortowanie sensorow dotykowych prawej reki wg wartosci odczytow
uint8_t BU21182FS_SortRight()
{
	uint8_t i, j, x;

	for(i = 0; i < BU_PRESSED_COUNT; i++)		// zerowanie tablicy
	{
		BU_pressed_right[i].lp = BU_SENSOR_COUNT;
		BU_pressed_right[i].value = 0;
	}

	for(i = 0; i < BU_PRESSED_COUNT; i++)		// znalezienie wartosci maksymalnej BU_PRESSED_COUNT razy
	{
		x = 0;
		for(j = 1; j < BU_SENSOR_COUNT; j++)	// zakres sensorow: 0 - 39, 56 - 58, 100 - 119
		{
			if(j == 40)
				j = 56;
			if(j == 59)
				j = 100;

			if(BU_states[j] > BU_states[x])
			{
				x = j;
			}
		}
		if(BU_states[x] < 76)					// odciecie szumow - uznanie wartosci jako 0
		{
			return i;							// zwraca ilosc niezerowych sensorow
		}
		BU_pressed_right[i].lp = x;				// zapisanie znalezionego maksimum
		BU_pressed_right[i].value = BU_states[x];
		BU_states[x] = 0;						// wyzerowanie znalezionego maksimum przed kolejna iteracja
	}

	return BU_PRESSED_COUNT;
}

// wybranie sensorow prawej i lewej reki do wyslania
void BU21182FS_SortSelect(uint8_t left, uint8_t right)
{
	uint8_t r, l, i, tmp;
	uint8_t half = BU_PRESSED_COUNT / 2;

	for(i = 0; i < BU_PRESSED_COUNT; i++)		// zerowanie tablicy
	{
		BU_pressed[i].lp = BU_SENSOR_COUNT;
		BU_pressed[i].value = 0;
	}

	if((left >= half) && (right >= half))		// niezerowych sensorow prawej i lewej reki jest przynajmniej po 5
	{											// wysylanie 5 sensorow prawej i 5 sensorow lewej reki
		l = half;
		r = half;
	}
	else if((left <= half) && (right <= half))	// niezerowych sensorow prawej i lewej reki jest co najwyzej po 5
	{											// wysylanie wszystkich niezerowych sensorow
		l = left;
		r = right;
	}
	else
	{
		if(right < left)						// niezerowych sensorow prawej reki jest mniej niz lewej
		{
			r = right;							// wyslanie wszystkich niezerowych sensorow prawej reki
			tmp = BU_PRESSED_COUNT - r;			// i zapelnienie wolnego miejsca w tablicy niezerowymi sensorami lewej reki
			l = (left > tmp ? tmp : left);
		}
		else									// niezerowych sensorow prawej reki jest wiecej niz lewej
		{
			l = left;							// wyslanie wszystkich niezerowych sensorow lewej reki
			tmp = BU_PRESSED_COUNT - l;			// i zapelnienie wolnego miejsca w tablicy niezerowymi sensorami prawej reki
			r = (right > tmp ? tmp : right);
		}
	}

	for(i = 0; i < l; i++)						// przepisanie sensorow lewej reki
	{
		BU_pressed[i].lp = BU_pressed_left[i].lp;
		if(BU_pressed_left[i].value > 233)		// przeskalowanie wysylanej wartosci
			BU_pressed[i].value = 0xf;
		else
			BU_pressed[i].value = (BU_pressed_left[i].value - 54) / 12;
	}
	for(i = 0; i < r; i++)						// przepisanie sensorow prawej reki
	{
		BU_pressed[i + l].lp = BU_pressed_right[i].lp;
		if(BU_pressed_right[i].value > 233)		// przeskalowanie wysylanej wartosci
			BU_pressed[i + l].value = 0xf;
		else
			BU_pressed[i + l].value = (BU_pressed_right[i].value - 54) / 12;
	}
}

// sprawdzenie odczytow z sensorow dotykowych
void BU21182FS_CheckStates()
{
	// odczytanie stanu sensorow
	for(uint8_t i = 0; i < BU_COUNT; i++)
		BU21182FS_GetValues(bu_addr + i, BU_states + (i * 20));

	// wybranie sensorow do wyslania
	BU21182FS_SortSelect(BU21182FS_SortLeft(), BU21182FS_SortRight());
}

// wyzerowanie stanu touchpada przed ponownym wlaczenie pendanta
void BU21182FS_Reinit()
{
	for(uint8_t i = 0; i < BU_SENSOR_COUNT; i++)
		BU_states[i] = 0;
}
