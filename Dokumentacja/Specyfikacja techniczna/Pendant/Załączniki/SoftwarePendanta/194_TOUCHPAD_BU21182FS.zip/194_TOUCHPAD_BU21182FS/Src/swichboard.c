/*
 * swichboard.c
 *
 *  Created on: 15.05.2020
 */

#include <stdio.h>
#include "main.h"
#include "switchboard.h"
#include "uart.h"

SB_state switch_states[SWITCH_NUMBER];			// tablica zawierajaca informacje o zmianie poszczegolnych przyciskow
SB_outPin SB_pin[9];							// tablica zawierajaca strukture przyciskow, kazdy element odpowiada innemu wyjsciu K_y_OUTx
uint8_t changed = SB_NOT_CHANGED;				// zmienna okreslajaca, czy ktorys przycisk zmienil stan
uint8_t SB_send_pressed[4];						// bufor nadawczy - przycisniety przycisk
uint8_t SB_send_unpressed[4];					// bufor nadawczy - puszczony przycisk

void check_change(SB_outPin *pin)				// sprawdzenie zmiany stanow przyciskow
{
	uint16_t tmp = pin->old_state ^ pin->new_state;
	uint8_t i;

	changed = SB_CHANGED;
	for(i = 0; i < pin->size; i++)
	{
		if(tmp & (1 << i))						// wyodrebnienie przyciskow ze zmienionym stanem
		{
			if(pin->new_state & (1 << i))
				pin->state_tab[i] = unpressed;
			else
				pin->state_tab[i] = pressed;
		}
	}
	pin->old_state = pin->new_state;
}

void SB_check_KA(SB_outPin *pin)				// funkjca sprawdzajaca przyciski podlaczone do pinow K_AXIS_OUTx
{
	uint32_t tmpA, tmpB, tmp, tmp4;

	HAL_GPIO_WritePin(GPIOB, pin->pin, 0);
	tmpA = GPIOA->IDR & 0x1ec0;
	tmpB = GPIOB->IDR & 0x1023;
	HAL_GPIO_WritePin(GPIOB, pin->pin, 1);
	tmpA = (tmpA & 0x1ec0) >> 6;
	tmp = (tmpB & 0x0020) << 4;
	tmp4 = (tmpB & 0x1000) >> 10;
	tmpB = (tmpB & 0x0003) << 7;
	tmp = tmp | tmpA | tmpB | tmp4;
	tmpA = (tmp & 0x1f) << 5;
	tmpB = tmp >> 5;
	pin->new_state = (uint16_t)(tmpA | tmpB);
	if(pin->new_state != pin->old_state)
		check_change(pin);
}

void SB_check_KL(SB_outPin *pin)				// funkjca sprawdzajaca przyciski podlaczone do pinow K_L_OUTx
{
	uint32_t tmp;

	HAL_GPIO_WritePin(GPIOC, pin->pin, 0);
	tmp = GPIOC->IDR;
	HAL_GPIO_WritePin(GPIOC, pin->pin, 1);
	pin->new_state = (uint16_t)(tmp & 0x000f);
	if(pin->new_state != pin->old_state)
		check_change(pin);
}

void SB_check_KN(SB_outPin *pin)				// funkjca sprawdzajaca przyciski podlaczone do pinow K_NUM_OUTx
{
	uint32_t tmpB, tmpC, tmpD;

	HAL_GPIO_WritePin(GPIOC, pin->pin, 0);
	tmpB = GPIOB->IDR;
	tmpC = GPIOC->IDR;
	tmpD = GPIOD->IDR;
	HAL_GPIO_WritePin(GPIOC, pin->pin, 1);
	tmpB = (tmpB & 0x2000) >> 12;
	tmpC = (tmpC & 0x1d00) >> 8;
	tmpD = (tmpD & 0x0004) << 3;
	pin->new_state = (uint16_t)(tmpB | tmpC | tmpD);
	if(pin->new_state != pin->old_state)
		check_change(pin);
}

void SB_init()									// inicjalizacja struktury przyciskow i buforow nadawczych
{
	uint8_t i = 0, ind = 0;

	SB_pin[i].old_state = 0x0007;
	SB_pin[i].new_state = 0x0007;
	SB_pin[i].size = 3;
	SB_pin[i].function = SB_check_KL;
	for(i = 1; i < 4; i++)
	{
		SB_pin[i].old_state = 0x000f;
		SB_pin[i].new_state = 0x000f;
		SB_pin[i].size = 4;
		SB_pin[i].function = SB_check_KL;
	}
	for(i = 4; i < 7; i++)
	{
		SB_pin[i].old_state = 0x003f;
		SB_pin[i].new_state = 0x003f;
		SB_pin[i].size = 6;
		SB_pin[i].function = SB_check_KN;
	}
	for(i = 7; i < 9; i++)
	{
		SB_pin[i].old_state = 0x03ff;
		SB_pin[i].new_state = 0x03ff;
		SB_pin[i].size = 10;
		SB_pin[i].function = SB_check_KA;
	}
	SB_pin[0].pin = KL_OUT3_Pin;
	SB_pin[1].pin = KL_OUT2_Pin;
	SB_pin[2].pin = KL_OUT1_Pin;
	SB_pin[3].pin = KL_OUT4_Pin;
	SB_pin[4].pin = KN_OUT0_Pin;
	SB_pin[5].pin = KN_OUT1_Pin;
	SB_pin[6].pin = KN_OUT2_Pin;
	SB_pin[7].pin = KA_OUT0_Pin;
	SB_pin[8].pin = KA_OUT1_Pin;

	for(i = 0; i < 9; i++)
	{
		SB_pin[i].state_tab = switch_states + ind;
		ind += SB_pin[i].size;
	}

	for(i = 0; i < SWITCH_NUMBER; i++)
		switch_states[i] = not_changed;

	SB_send_pressed[0] = 255;
	SB_send_unpressed[0] = 255;
	SB_send_pressed[1] = FRAME_TYPE_BUTTON_DOWN;
	SB_send_unpressed[1] = FRAME_TYPE_BUTTON_UP;
}

void SB_reinit()
{
	uint8_t i = 0;

	SB_pin[i].old_state = 0x0007;
	SB_pin[i].new_state = 0x0007;
	for(i = 1; i < 4; i++)
	{
		SB_pin[i].old_state = 0x000f;
		SB_pin[i].new_state = 0x000f;
	}
	for(i = 4; i < 7; i++)
	{
		SB_pin[i].old_state = 0x003f;
		SB_pin[i].new_state = 0x003f;
	}
	for(i = 7; i < 9; i++)
	{
		SB_pin[i].old_state = 0x03ff;
		SB_pin[i].new_state = 0x03ff;
	}

	for(i = 0; i < SWITCH_NUMBER; i++)
		switch_states[i] = not_changed;
}

void SB_send(UART_HandleTypeDef *huart)
{
	uint8_t i;
#ifdef VERBOSE
	uint8_t len, buf[20];

	changed = SB_NOT_CHANGED;					// reset zmiennej oznaczajacej zmiane ktoregokolwiek przycisku
	for(i = 0; i < SWITCH_NUMBER; i++)
	{
		if(switch_states[i] == pressed)
		{
			len = (uint8_t)sprintf((char*)buf, "\t\t\t%u\t\t\tpressed\r\n", i);
			HAL_UART_Transmit(huart, buf, len, 100);
		}
		if(switch_states[i] == unpressed)
		{
			len = (uint8_t)sprintf((char*)buf, "\t\t\t\t%u\t\tunpressed\r\n", i);
			HAL_UART_Transmit(huart, buf, len, 100);
		}
		switch_states[i] = not_changed;			// reset zmiennej oznaczajacej zmiane wybranego przycisku
	}

	return;
#endif
	changed = SB_NOT_CHANGED;					// reset zmiennej oznaczajacej zmiane ktoregokolwiek przycisku
	for(i = 0; i < SWITCH_NUMBER; i++)
	{
		if(switch_states[i] == pressed)
		{
			SB_send_pressed[2] = i;
			SB_send_pressed[3] = FRAME_TYPE_BUTTON_DOWN ^ i;		// policzenie crc
			HAL_UART_Transmit(huart, SB_send_pressed, UART_TX_FRAME_SIZE, 100);
		}
		if(switch_states[i] == unpressed)
		{
			SB_send_unpressed[2] = i;
			SB_send_unpressed[3] = FRAME_TYPE_BUTTON_UP ^ i;		// policzenie crc
			HAL_UART_Transmit(huart, SB_send_unpressed, UART_TX_FRAME_SIZE, 100);
		}
		switch_states[i] = not_changed;			// reset zmiennej oznaczajacej zmiane wybranego przycisku
	}
}

uint8_t SB_checkAll()
{
	uint8_t i;

	for(i = 0; i < 9; i++)						// sprawdzenie stanu wszystkich przyciskow
	{
		SB_pin[i].function(SB_pin + i);
	}

	return changed;								// zwraca informacje o zmianie przynajmniej jednego przycisku
}

