/*
 * uart.c
 *
 *  Created on: 18.05.2020
 */


#include <stdio.h>
#include "main.h"
#include "uart.h"


uint8_t UART_start = 0;				// flaga komendy start
uint8_t UART_stop = 0;				// flaga komendy stop
uint8_t UART_rx_char = 0;			// indeks odebranego znaku komendy
uint8_t UART_rx_buf;				// bufor odbiorczy
uint8_t UART_tim_counter = 0;		// licznik watchdoga
UART_HandleTypeDef *my_huart;		// wskaznik na UART

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	UART_tim_counter++;				// co 20 ms
	if(UART_tim_counter == 10)
	{
		UART_tim_counter = 0;		// po 200 ms bez odebrania znaku UART
		// ponowne rozpoczecie odbierania przez przerwanie
		HAL_UART_Receive_IT(my_huart, &UART_rx_buf, 1);
	}
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	UART_tim_counter = 0;			// zerowanie licznika watchdoga
	// komenda "start\r":	UART_rx_char = {0, 1, 2, 3, 4, 5}
	// komenda "stop\r":	UART_rx_char = {0, 1, 2, 6, 7}
	switch(UART_rx_buf)
	{
	case 's':
	{
		UART_rx_char = 1;
		break;
	}
	case 't':
	{
		if((UART_rx_char == 1) || (UART_rx_char == 4))
			UART_rx_char++;
		else
			UART_rx_char = 0;
		break;
	}
	case 'a':
	{
		if(UART_rx_char == 2)
			UART_rx_char++;
		else
			UART_rx_char = 0;
		break;
	}
	case 'r':
	{
		if(UART_rx_char == 3)
			UART_rx_char++;
		else
			UART_rx_char = 0;
		break;
	}
	case '\r':
	{
		if(UART_rx_char == 5)		// odebranie ciagu znakow "start\r"
			UART_start = 1;
		if(UART_rx_char == 7)		// odebranie ciagu znakow "stop\r"
			UART_stop = 1;
		UART_rx_char = 0;
		break;
	}
	case 'o':
	{
		if(UART_rx_char == 2)
			UART_rx_char = 6;
		else
			UART_rx_char = 0;
		break;
	}
	case 'p':
	{
		if(UART_rx_char == 6)
			UART_rx_char++;
		else
			UART_rx_char = 0;
		break;
	}
	default:
		UART_rx_char = 0;
	}
	HAL_UART_Receive_IT(huart, &UART_rx_buf, 1);
}

// inicjalizacja transmisji UART
void UART_init(UART_HandleTypeDef *huart, TIM_HandleTypeDef *htim)
{
	HAL_UART_Receive(huart, &UART_rx_buf, 1, 10);	// wyczyszczenie buforu
	HAL_UART_Receive_IT(huart, &UART_rx_buf, 1);	// odbieranie po 1 bajcie
	HAL_TIM_Base_Start_IT(htim);					// timer do watchdoga
	my_huart = huart;
}

// odczytanie flagi komendy start
uint8_t UART_getStart()
{
	uint8_t tmp = UART_start;

	UART_start = 0;									// skasowanie flagi komendy start

	return tmp;
}

// odczytanie flagi komendy stop
uint8_t UART_getStop()
{
	uint8_t tmp = UART_stop;

	UART_stop = 0;									// skasowanie flagi komendy stop

	return tmp;
}
