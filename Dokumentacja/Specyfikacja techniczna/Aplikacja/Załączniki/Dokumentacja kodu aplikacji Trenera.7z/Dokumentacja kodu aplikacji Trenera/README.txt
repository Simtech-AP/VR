Aby otworzyć dokumentację w formacie html należy otworzyć plik html/index.html
Aby otrzymać dokumentację w formacie latex należy wybudować plik latex/refman.tex do pliku pdf.