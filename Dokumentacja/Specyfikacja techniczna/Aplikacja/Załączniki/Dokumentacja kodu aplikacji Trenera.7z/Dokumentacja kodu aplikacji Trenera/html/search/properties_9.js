var searchData=
[
  ['sample_391',['Sample',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#ab86b32b5dff6c9c00780f1a32d543187',1,'Adrenak::UniMic::Mic']]],
  ['sampledurationms_392',['SampleDurationMS',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#afe0d9228bd91287f0fe630c6fdfecadf',1,'Adrenak::UniMic::Mic']]],
  ['samplelen_393',['SampleLen',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#a18cdfaf9c778c19148e04ec30500becb',1,'Adrenak::UniMic::Mic']]],
  ['server_394',['Server',['../d8/dae/classDarkRift_1_1Server_1_1Unity_1_1UnityServer.html#aa03786ec0cf5d97df86e240e5ee7e801',1,'DarkRift.Server.Unity.UnityServer.Server()'],['../d3/d87/classDarkRift_1_1Server_1_1Unity_1_1XmlUnityServer.html#a421878e2e8bc22d6c2a1036a508eeafd',1,'DarkRift.Server.Unity.XmlUnityServer.Server()']]]
];
