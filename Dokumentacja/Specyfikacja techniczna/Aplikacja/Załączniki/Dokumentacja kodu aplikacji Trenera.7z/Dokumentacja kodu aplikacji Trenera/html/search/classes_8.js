var searchData=
[
  ['ipayload_217',['IPayload',['../d1/d2c/interfaceAdrenak_1_1AirPeer_1_1IPayload.html',1,'Adrenak::AirPeer']]]
];
