var searchData=
[
  ['getlocalindex_293',['GetLocalIndex',['../d4/dfb/classAdrenak_1_1UniVoice_1_1AudioBuffer.html#a7658ec0b8074a10819e19f79b3c0bf51',1,'Adrenak::UniVoice::AudioBuffer']]],
  ['getoutputdata_294',['GetOutputData',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#a6e1033bc9a41f1f6058ad4a37ced22dd',1,'Adrenak::UniMic::Mic']]],
  ['getselectedstreamui_295',['GetSelectedStreamUI',['../d8/d9e/classUIController.html#a4f4182d3943abd1a57fd5be0ecee9cc3',1,'UIController']]],
  ['getspectrumdata_296',['GetSpectrumData',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#aa611a4c5437d222ebd345ffe40ac4696',1,'Adrenak::UniMic::Mic']]],
  ['getstreambystreamui_297',['GetStreamByStreamUI',['../da/d2f/classStreamController.html#a42489da32cd52cf3d364cf8c738202b9',1,'StreamController']]],
  ['getstreams_298',['GetStreams',['../da/d2f/classStreamController.html#a43d955e13ae587b81d3679d4930446a6',1,'StreamController']]]
];
