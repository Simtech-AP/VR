var searchData=
[
  ['volumegate_349',['VolumeGate',['../d5/da2/classAdrenak_1_1UniVoice_1_1VolumeGate.html#a7ba3b25190b7b8561f4d9a29ee1a5902',1,'Adrenak::UniVoice::VolumeGate']]]
];
