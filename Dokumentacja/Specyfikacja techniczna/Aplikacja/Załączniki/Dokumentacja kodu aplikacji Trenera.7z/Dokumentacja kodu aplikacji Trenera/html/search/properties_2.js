var searchData=
[
  ['databases_367',['Databases',['../d8/dae/classDarkRift_1_1Server_1_1Unity_1_1UnityServer.html#a3e607c311f9835dfe681a0cdc7d5a6e2',1,'DarkRift::Server::Unity::UnityServer']]],
  ['datadirectory_368',['DataDirectory',['../d8/dae/classDarkRift_1_1Server_1_1Unity_1_1UnityServer.html#a7402325ef76827de8e58af9ca2c38f4e',1,'DarkRift::Server::Unity::UnityServer']]],
  ['devices_369',['Devices',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#a7e55e4e221ddf41417dc1386851bd0d7',1,'Adrenak::UniMic::Mic']]],
  ['dispatcher_370',['Dispatcher',['../dc/d51/classDarkRift_1_1Client_1_1Unity_1_1UnityClient.html#a73f64ab8bf774812440ce62a3a0482cc',1,'DarkRift::Client::Unity::UnityClient']]]
];
