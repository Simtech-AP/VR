var searchData=
[
  ['ongetbytes_397',['OnGetBytes',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#aa6a2a5823aafeace9a23ae58e87d4081',1,'Adrenak::AirPeer::Node']]],
  ['ongetpacket_398',['OnGetPacket',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#a22617a49d543521ae726a2cc0eeb032c',1,'Adrenak::AirPeer::Node']]],
  ['onjoin_399',['OnJoin',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#a88ebade15905f2e5e2ca96fcafb07ac8',1,'Adrenak::AirPeer::Node']]],
  ['onleave_400',['OnLeave',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#acb6751d85edfec5ab8e01fe4a8500e90',1,'Adrenak::AirPeer::Node']]],
  ['onsampleready_401',['OnSampleReady',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#aeab52fef94983cd5995ce2f6317964f8',1,'Adrenak::UniMic::Mic']]],
  ['onserverstopped_402',['OnServerStopped',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#a96e45748595286f71d6f26aaf43a644e',1,'Adrenak::AirPeer::Node']]],
  ['onstartrecording_403',['OnStartRecording',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#a33ee8032906f85e1a96bba3ff4fa32b2',1,'Adrenak::UniMic::Mic']]],
  ['onstoprecording_404',['OnStopRecording',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#ae3147afd7e3299fcaa6395b58015ac64',1,'Adrenak::UniMic::Mic']]]
];
