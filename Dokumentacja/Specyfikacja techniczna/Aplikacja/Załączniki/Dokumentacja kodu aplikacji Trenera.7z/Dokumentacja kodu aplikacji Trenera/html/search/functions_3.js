var searchData=
[
  ['deinit_278',['Deinit',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#a7449aea70bc39a5c9597fbee65958b5a',1,'Adrenak::AirPeer::Node']]],
  ['dequeue_279',['Dequeue',['../d2/dec/classByn_1_1Net_1_1BrowserWebRtcNetwork.html#a1441a2d09229b5a78737cda299a5be4e',1,'Byn::Net::BrowserWebRtcNetwork']]],
  ['destroystream_280',['DestroyStream',['../da/d2f/classStreamController.html#a885289d663df6286a6b4ba1f28c479ad',1,'StreamController.DestroyStream()'],['../d8/d9e/classUIController.html#a1234fd4663f7b1fafe3d69b6808dd0a4',1,'UIController.DestroyStream()']]],
  ['disconnect_281',['Disconnect',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#a9301d639def1d0e710c699ce75b91e91',1,'Adrenak.AirPeer.Node.Disconnect()'],['../d2/dec/classByn_1_1Net_1_1BrowserWebRtcNetwork.html#a70b4b381ac2e3d2bbf2f29451903aee7',1,'Byn.Net.BrowserWebRtcNetwork.Disconnect()'],['../dc/d51/classDarkRift_1_1Client_1_1Unity_1_1UnityClient.html#aebe4af1fa8b687bde831edd9c59dfea8',1,'DarkRift.Client.Unity.UnityClient.Disconnect()']]],
  ['dispose_282',['Dispose',['../d2/dec/classByn_1_1Net_1_1BrowserWebRtcNetwork.html#a4d5574d66b724b683b03533ef34078a4',1,'Byn::Net::BrowserWebRtcNetwork']]]
];
