var searchData=
[
  ['address_359',['Address',['../dc/d51/classDarkRift_1_1Client_1_1Unity_1_1UnityClient.html#ad7996fa0270f359f4aabc7d1d0ec03c5',1,'DarkRift.Client.Unity.UnityClient.Address()'],['../d8/dae/classDarkRift_1_1Server_1_1Unity_1_1UnityServer.html#a231ae4190b13733e895490d94dc17090',1,'DarkRift.Server.Unity.UnityServer.Address()']]]
];
