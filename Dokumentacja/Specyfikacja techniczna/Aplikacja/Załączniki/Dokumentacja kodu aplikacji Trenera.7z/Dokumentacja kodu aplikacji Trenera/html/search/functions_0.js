var searchData=
[
  ['audiobuffer_264',['AudioBuffer',['../d4/dfb/classAdrenak_1_1UniVoice_1_1AudioBuffer.html#a0efcaaa0b583ec7bc3f968435a3735ef',1,'Adrenak::UniVoice::AudioBuffer']]]
];
