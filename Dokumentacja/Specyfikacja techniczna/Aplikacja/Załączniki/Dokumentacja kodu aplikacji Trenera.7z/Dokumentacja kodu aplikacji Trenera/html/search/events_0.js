var searchData=
[
  ['disconnected_395',['Disconnected',['../dc/d51/classDarkRift_1_1Client_1_1Unity_1_1UnityClient.html#a3846072309c028db2eb6225d17c88ce2',1,'DarkRift::Client::Unity::UnityClient']]]
];
