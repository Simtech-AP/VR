var searchData=
[
  ['leave_303',['Leave',['../d5/df6/classAdrenak_1_1UniVoice_1_1Voice.html#aa3cd405ae2855169e53d5b9504cb770e',1,'Adrenak::UniVoice::Voice']]]
];
