var searchData=
[
  ['xmlunityclienteditor_197',['XmlUnityClientEditor',['../d0/d37/classDarkRift_1_1Server_1_1Unity_1_1XmlUnityClientEditor.html',1,'DarkRift::Server::Unity']]],
  ['xmlunityserver_198',['XmlUnityServer',['../d3/d87/classDarkRift_1_1Server_1_1Unity_1_1XmlUnityServer.html',1,'DarkRift::Server::Unity']]]
];
