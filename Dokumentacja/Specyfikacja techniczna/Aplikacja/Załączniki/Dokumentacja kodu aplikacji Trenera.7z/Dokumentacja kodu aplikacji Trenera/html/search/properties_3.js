var searchData=
[
  ['frequency_371',['Frequency',['../de/d3c/classAdrenak_1_1UniMic_1_1Mic.html#ad639fc506494469110fa2f9664c729e8',1,'Adrenak::UniMic::Mic']]]
];
