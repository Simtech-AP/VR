var searchData=
[
  ['savedscenarioscrollposition_356',['savedScenarioScrollPosition',['../d8/d9e/classUIController.html#a1199ff8f497ca4c7bcfb4297c90ccf20',1,'UIController']]],
  ['streamui_357',['streamUI',['../dc/de8/classStream.html#a87d6b023df266ae1406dcb3336aa1458',1,'Stream']]]
];
