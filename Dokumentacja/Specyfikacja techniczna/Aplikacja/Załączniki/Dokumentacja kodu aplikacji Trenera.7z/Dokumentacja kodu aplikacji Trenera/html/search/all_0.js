var searchData=
[
  ['_5ftexturereceiver_0',['_TextureReceiver',['../d5/d2c/classTextureSendReceive_1_1__TextureReceiver.html',1,'TextureSendReceive']]],
  ['_5ftexturesender_1',['_TextureSender',['../d0/d27/classTextureSendReceive_1_1__TextureSender.html',1,'TextureSendReceive']]]
];
