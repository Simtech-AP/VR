var searchData=
[
  ['objectcachesettings_388',['ObjectCacheSettings',['../dc/d51/classDarkRift_1_1Client_1_1Unity_1_1UnityClient.html#ae0828a5bfdf012a614408997433f31fa',1,'DarkRift::Client::Unity::UnityClient']]]
];
