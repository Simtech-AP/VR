var searchData=
[
  ['join_92',['Join',['../d5/df6/classAdrenak_1_1UniVoice_1_1Voice.html#ad724da4483492c4802f2f66997fe5291',1,'Adrenak::UniVoice::Voice']]]
];
