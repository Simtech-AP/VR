var searchData=
[
  ['new_304',['New',['../d6/d72/classAdrenak_1_1AirPeer_1_1Node.html#a7fb880fd28d4ff2d73528db812a69641',1,'Adrenak.AirPeer.Node.New()'],['../d1/d76/classAdrenak_1_1UniVoice_1_1AudioStreamer.html#a692a2b096954ac6fea7c150c2799f8ed',1,'Adrenak.UniVoice.AudioStreamer.New()'],['../d5/df6/classAdrenak_1_1UniVoice_1_1Voice.html#a61ca5c48e274b66953a8b8b2df1a5892',1,'Adrenak.UniVoice.Voice.New()']]],
  ['nextmodule_305',['NextModule',['../d4/d97/classConnectionController.html#ae9462a81de72776338675e9061c2e812',1,'ConnectionController']]]
];
