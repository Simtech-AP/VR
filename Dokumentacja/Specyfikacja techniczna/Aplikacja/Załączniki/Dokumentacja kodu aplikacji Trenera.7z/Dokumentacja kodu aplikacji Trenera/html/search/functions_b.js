var searchData=
[
  ['processdebugdata_306',['ProcessDebugData',['../d8/d9e/classUIController.html#a71e83133ea0eac23b46ee618dceb8632',1,'UIController']]],
  ['processlanguages_307',['ProcessLanguages',['../d8/d9e/classUIController.html#abbe4431fb941eb7705a9635dc353abe8',1,'UIController']]]
];
