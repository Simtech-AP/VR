var searchData=
[
  ['browserwebrtcnetwork_265',['BrowserWebRtcNetwork',['../d2/dec/classByn_1_1Net_1_1BrowserWebRtcNetwork.html#a06e5b8eb715a217d765cf5be60d30150',1,'Byn.Net.BrowserWebRtcNetwork.BrowserWebRtcNetwork(string websocketUrl, IceServer[] lIceServers)'],['../d2/dec/classByn_1_1Net_1_1BrowserWebRtcNetwork.html#a3c4e0f6a29e5accb92221ac39dff901c',1,'Byn.Net.BrowserWebRtcNetwork.BrowserWebRtcNetwork()']]]
];
