var searchData=
[
  ['lectorvolumelevel_354',['lectorVolumeLevel',['../de/d08/classClientData.html#ad4f58642b9e4317aa5eeb030d3f0b9c4',1,'ClientData']]]
];
